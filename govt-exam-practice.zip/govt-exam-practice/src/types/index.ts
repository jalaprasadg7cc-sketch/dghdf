export type ExamCategory =
  | "SSC"
  | "Banking"
  | "Railway"
  | "UPSC"
  | "State PSC";

export interface Exam {
  id: string;
  name: string;
  fullName: string;
  category: ExamCategory;
  description: string;
  papersCount: number;
  questionsCount: number;
  aspirantsCount: number; // displayed as "aspirants practicing"
  colorAccent: "marigold" | "emerald" | "navy" | "crimson";
  subjects: string[];
}

export interface QuestionOption {
  id: string; // "A" | "B" | "C" | "D"
  text: string;
}

export interface Question {
  id: string;
  examId: string;
  subject: string;
  topic: string;
  year: number;
  questionText: string;
  options: QuestionOption[];
  correctOptionId: string;
  explanation: string;
  difficulty: "Easy" | "Medium" | "Hard";
}

export type AnswerStatus = "answered" | "unanswered" | "bookmarked" | "reviewed";

export interface UserAnswer {
  questionId: string;
  selectedOptionId: string | null;
  status: AnswerStatus;
  timeSpentSeconds: number;
}

export interface TestResult {
  id: string;
  examId: string;
  examName: string;
  dateTaken: string;
  totalQuestions: number;
  correct: number;
  incorrect: number;
  unanswered: number;
  score: number;
  maxScore: number;
  accuracy: number; // percentage
  timeTakenMinutes: number;
}

export interface TopicPerformance {
  topic: string;
  subject: string;
  accuracy: number;
  questionsAttempted: number;
}
