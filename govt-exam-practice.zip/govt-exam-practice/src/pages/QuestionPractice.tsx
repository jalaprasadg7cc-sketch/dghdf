import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";

// Placeholder — built in the next step of this build-out.
export default function QuestionPractice() {
  return (
    <div className="min-h-screen flex flex-col bg-paper">
      <Navbar />
      <main className="flex-1 flex items-center justify-center px-5">
        <div className="text-center max-w-md">
          <p className="font-mono text-xs uppercase tracking-widest text-marigold-dark mb-3">
            Coming next
          </p>
          <h1 className="font-display text-3xl font-semibold text-ink-navy mb-3">
            QuestionPractice page
          </h1>
          <p className="text-slate">
            This page is scaffolded and routed, and will be designed in the next step.
          </p>
        </div>
      </main>
      <Footer />
    </div>
  );
}
