# PYQ Setu — Government Exam PYQ Practice Platform (Frontend Prototype)

Frontend-only prototype. No backend/database — all data is mocked in `src/data/`.

## Stack
- React 18 + TypeScript
- Vite
- Tailwind CSS
- React Router v6
- lucide-react (icons)

## Getting started
```bash
npm install
npm run dev
```
Then open http://localhost:5173

## Folder structure
```
src/
├── components/
│   ├── layout/     Navbar, Footer
│   ├── common/     Button, (Modal/ProgressBar coming in later steps)
│   └── exam/       ExamCard, AdmitCardWidget, (QuestionCard/ResultSummary/Sidebar coming next)
├── pages/          One file per route
├── data/           Mock data — the ONLY place with hardcoded content
├── types/          Shared TypeScript interfaces
├── config/         Brand config (site name, tagline)
└── utils/          Helper functions (added as needed)
```

## Status
- [x] Project scaffold + routing
- [x] Landing / Home page
- [ ] Exam Selection page
- [ ] Exam Details page
- [ ] Question Practice page
- [ ] Mock Test page
- [ ] Results page
- [ ] User Dashboard

## Rebranding
Change `SITE_NAME` and `SITE_TAGLINE` in `src/config/site.ts` — nothing else needs to change.
