# PYQ Setu — Government Exam PYQ Practice Platform

Frontend: React 18 + TypeScript + Vite + Tailwind + React Router.
Database: Supabase (PostgreSQL) — schema and RLS policies in `supabase/`.

## Stack
- React 18 + TypeScript
- Vite
- Tailwind CSS
- React Router v6
- lucide-react (icons)
- Supabase (PostgreSQL, Auth) — see `supabase/README.md`

## Getting started
```bash
npm install
npm run dev
```
Then open http://localhost:5173

## Folder structure
```
src/
├── components/
│   ├── layout/     Navbar, Footer
│   ├── common/     Button, Modal, ProgressBar
│   └── exam/       ExamCard, AdmitCardWidget, ExamSession, QuestionCard,
│                   OptionButton, QuestionPalette, SessionHeader, SubmitModal
├── pages/          One file per route (QuestionPractice & MockTest are thin
│                   wrappers around the shared ExamSession engine)
├── hooks/          useExamSession (state engine), useTimer (count-up/countdown)
├── data/           Mock data — the ONLY place with hardcoded content (until
│                   pages are wired to Supabase)
├── types/          Shared TypeScript interfaces
├── config/         Brand config (site name, tagline)
└── utils/          time.ts — timer formatting
supabase/
├── migrations/     SQL migration(s) — schema, RLS, secure views, grading function
└── README.md       How to apply the migration + how the frontend should query it
```

## Status
- [x] Project scaffold + routing
- [x] Landing / Home page
- [x] Question Practice page (Practice Mode)
- [x] Mock Test page (Mock Test Mode) — shares the same ExamSession engine
- [x] Database schema (Supabase/Postgres) — content tables + auth, no attempt/result persistence
- [ ] Wire pages to Supabase (currently still reading from `src/data/` mocks)
- [ ] Exam Selection page
- [ ] Exam Details page
- [ ] Results page (currently a placeholder; ExamSession already navigates
      here with a score summary via router state, ready for the real build)
- [ ] User Dashboard

## Practice Mode vs Mock Test Mode
Both are powered by one `<ExamSession mode="practice" | "mock-test" />` component,
one `useExamSession` state hook, and a `feedbackMode` prop:
- **Practice** (`feedbackMode="after-submit"`): correctness and explanations are
  never shown mid-session — only after the user submits, via the results payload.
- **Mock Test**: countdown timer auto-submits at zero, same after-submit feedback
  behavior, action bar shows "Save & Next" / "Mark for Review & Next".

The question palette uses 5 independent states (not-visited, not-answered,
answered, marked-for-review, answered-and-marked-for-review) — matching the
real logic used in competitive-exam interfaces, where "answered" and "marked
for review" are independent flags rather than one status.

## Database
See `supabase/README.md` for the full schema reference, how to apply the
migration, and how to query it from the frontend (public views for content,
a single RPC for grading). Short version: correct answers and explanations
are structurally unreachable from the client until the moment a session is
submitted, and nothing about a user's attempt is ever persisted.

## Rebranding
Change `SITE_NAME` and `SITE_TAGLINE` in `src/config/site.ts` — nothing else needs to change.
