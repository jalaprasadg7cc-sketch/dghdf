-- ============================================================================
-- PYQ Setu — Initial content schema
-- ============================================================================
-- Scope: authentication (via Supabase Auth) + exam content (categories, exams,
-- subjects, previous year papers, questions, options).
--
-- Explicitly OUT of scope by design: no tables for user practice attempts,
-- submitted answers, scores, or result history. Practice sessions run
-- entirely in frontend state. Grading is a stateless database function
-- (see bottom of this file) that computes a result on demand and writes
-- nothing to disk.
--
-- Security model for hiding correct answers / explanations:
--   1. `questions` and `question_options` have RLS enabled with NO select
--      policy for anon/authenticated — by default this denies all access
--      to every role except the table owner.
--   2. Two views (`public_questions`, `public_question_options`), owned by
--      the table owner, expose only the safe columns. Table owners bypass
--      their own RLS policies, so the views can read the base tables even
--      though ordinary roles cannot — but the views simply don't select
--      the sensitive columns, so those columns never leave the database
--      via this path.
--   3. `grade_practice_attempt()` is a SECURITY DEFINER function (owned by
--      the table owner) that accepts submitted answers, looks up
--      correctness directly against the base tables, and returns the
--      result — again, without ever writing anything.
-- ============================================================================

create extension if not exists "pgcrypto";

-- ----------------------------------------------------------------------------
-- 1. categories — lookup table (SSC, Banking, Railway, UPSC, State PSC, ...)
-- ----------------------------------------------------------------------------
create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  created_at timestamptz not null default now()
);

comment on table public.categories is 'Top-level exam categories (SSC, Banking, Railway, UPSC, State PSC, ...).';

-- ----------------------------------------------------------------------------
-- 2. exams
-- ----------------------------------------------------------------------------
create table public.exams (
  id uuid primary key default gen_random_uuid(),
  category_id uuid not null references public.categories(id) on delete restrict,
  name text not null,
  full_name text not null,
  slug text not null unique,
  description text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_exams_category_id on public.exams(category_id);

comment on table public.exams is 'Individual exams, e.g. SSC CGL, IBPS PO, RRB NTPC.';

-- ----------------------------------------------------------------------------
-- 3. subjects — global, reusable list (not duplicated per exam)
-- ----------------------------------------------------------------------------
create table public.subjects (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  created_at timestamptz not null default now()
);

comment on table public.subjects is 'Global subject/category list (Arithmetic, Reasoning, English, GK, ...). Reused across exams via exam_subjects.';

-- ----------------------------------------------------------------------------
-- 4. exam_subjects — many-to-many join between exams and subjects
-- ----------------------------------------------------------------------------
create table public.exam_subjects (
  exam_id uuid not null references public.exams(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete cascade,
  primary key (exam_id, subject_id)
);

create index idx_exam_subjects_subject_id on public.exam_subjects(subject_id);

comment on table public.exam_subjects is 'Which subjects are offered under which exam.';

-- ----------------------------------------------------------------------------
-- 5. previous_year_papers — a specific sitting of an exam
--    (replaces storing year/shift redundantly on every question row)
-- ----------------------------------------------------------------------------
create table public.previous_year_papers (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id) on delete cascade,
  year integer not null check (year between 1990 and 2100),
  appeared_date date,
  shift text,
  paper_name text,
  created_at timestamptz not null default now()
);

create index idx_papers_exam_id on public.previous_year_papers(exam_id);

-- Prevent duplicate paper entries for the same exam/year/shift/paper_name.
-- coalesce(..., '') treats NULL shift/paper_name consistently for dedup purposes.
create unique index uniq_paper_per_exam_year_shift
  on public.previous_year_papers (exam_id, year, coalesce(shift, ''), coalesce(paper_name, ''));

comment on table public.previous_year_papers is 'A specific previous-year paper sitting: exam + year + optional shift/paper name. Questions reference this instead of storing year/shift directly.';

-- ----------------------------------------------------------------------------
-- 6. questions
--    Sensitive columns: explanation (never exposed pre-submission).
-- ----------------------------------------------------------------------------
create table public.questions (
  id uuid primary key default gen_random_uuid(),
  paper_id uuid not null references public.previous_year_papers(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete restrict,
  question_text text not null,
  explanation text,
  difficulty text not null default 'Medium' check (difficulty in ('Easy', 'Medium', 'Hard')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_questions_paper_id on public.questions(paper_id);
create index idx_questions_subject_id on public.questions(subject_id);
create index idx_questions_paper_subject on public.questions(paper_id, subject_id);

comment on table public.questions is 'PYQ content. A paper mixes subjects (e.g. Tier I has Quant + Reasoning + English + GK together), so subject_id is kept alongside paper_id.';
comment on column public.questions.explanation is 'Sensitive: excluded from public_questions view, only returned by grade_practice_attempt() after submission.';

-- ----------------------------------------------------------------------------
-- 7. question_options
--    Sensitive column: is_correct (never exposed pre-submission).
-- ----------------------------------------------------------------------------
create table public.question_options (
  id uuid primary key default gen_random_uuid(),
  question_id uuid not null references public.questions(id) on delete cascade,
  option_label text not null check (option_label ~ '^[A-Z]$'),
  option_text text not null,
  is_correct boolean not null default false,
  created_at timestamptz not null default now()
);

create index idx_question_options_question_id on public.question_options(question_id);

-- At most one correct option per question.
create unique index one_correct_option_per_question
  on public.question_options (question_id)
  where (is_correct = true);

-- No two options with the same label on one question (no duplicate "A"s).
create unique index unique_option_label_per_question
  on public.question_options (question_id, option_label);

comment on table public.question_options is 'Answer options per question. is_correct is sensitive: excluded from public_question_options view.';
comment on column public.question_options.is_correct is 'Sensitive: excluded from public_question_options view, only resolved by grade_practice_attempt() after submission.';

-- ----------------------------------------------------------------------------
-- 8. profiles — 1:1 extension of Supabase's own auth.users
--    (email/password themselves live in the protected auth.users table,
--    managed entirely by Supabase Auth — we never touch that here)
-- ----------------------------------------------------------------------------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  avatar_url text,
  role text not null default 'student' check (role in ('student', 'admin')),
  created_at timestamptz not null default now()
);

comment on table public.profiles is 'App-facing user profile data. role drives write access to content tables via is_admin().';

-- ----------------------------------------------------------------------------
-- Helper functions
-- ----------------------------------------------------------------------------

-- Used inside RLS policies to gate content writes to admins.
-- Runs with the CALLER's rights: it only ever reads the caller's own profile
-- row, which the "Users can view own profile" policy already permits.
create function public.is_admin()
returns boolean
language sql
stable
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin'
  );
$$;

-- Auto-create a profile row whenever someone signs up via Supabase Auth.
-- SECURITY DEFINER is required here: profiles has no INSERT policy at all
-- (profile creation should only ever happen through this trigger), so this
-- function must run with elevated privilege to succeed.
create function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, new.raw_user_meta_data ->> 'full_name');
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Blocks a user from self-promoting to admin via a normal profile update.
-- Without this, the "Users can update own profile" policy below would let
-- any authenticated user PATCH their own role column directly.
create function public.prevent_role_escalation()
returns trigger
language plpgsql
as $$
begin
  if new.role is distinct from old.role and not public.is_admin() then
    new.role := old.role;
  end if;
  return new;
end;
$$;

create trigger trg_prevent_role_escalation
  before update on public.profiles
  for each row execute function public.prevent_role_escalation();

-- Generic updated_at maintenance.
create function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger trg_exams_updated_at
  before update on public.exams
  for each row execute function public.set_updated_at();

create trigger trg_questions_updated_at
  before update on public.questions
  for each row execute function public.set_updated_at();

-- ----------------------------------------------------------------------------
-- Row Level Security
-- ----------------------------------------------------------------------------

-- Freely browsable content: public read, admin-only write.
alter table public.categories enable row level security;
alter table public.exams enable row level security;
alter table public.subjects enable row level security;
alter table public.exam_subjects enable row level security;
alter table public.previous_year_papers enable row level security;

create policy "Public can read categories" on public.categories
  for select using (true);
create policy "Admins can manage categories" on public.categories
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Public can read exams" on public.exams
  for select using (true);
create policy "Admins can manage exams" on public.exams
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Public can read subjects" on public.subjects
  for select using (true);
create policy "Admins can manage subjects" on public.subjects
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Public can read exam_subjects" on public.exam_subjects
  for select using (true);
create policy "Admins can manage exam_subjects" on public.exam_subjects
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Public can read papers" on public.previous_year_papers
  for select using (true);
create policy "Admins can manage papers" on public.previous_year_papers
  for all using (public.is_admin()) with check (public.is_admin());

-- Sensitive content: RLS enabled with NO select policy for anon/authenticated.
-- This denies direct reads to everyone except the table owner. Admins still
-- manage content through the "for all" policy below (INSERT/UPDATE/DELETE);
-- ordinary reads only ever happen through public_questions /
-- public_question_options (see views) or grade_practice_attempt().
alter table public.questions enable row level security;
alter table public.question_options enable row level security;

create policy "Admins can manage questions" on public.questions
  for all using (public.is_admin()) with check (public.is_admin());
create policy "Admins can manage question_options" on public.question_options
  for all using (public.is_admin()) with check (public.is_admin());

-- profiles: users can only see/edit their own row.
alter table public.profiles enable row level security;

create policy "Users can view own profile" on public.profiles
  for select using (auth.uid() = id);
create policy "Users can update own profile" on public.profiles
  for update using (auth.uid() = id) with check (auth.uid() = id);

-- ----------------------------------------------------------------------------
-- Secure public views — the only read path for questions/options
-- ----------------------------------------------------------------------------

create view public.public_questions as
select
  id,
  paper_id,
  subject_id,
  question_text,
  difficulty,
  created_at
from public.questions;

comment on view public.public_questions is 'Client-facing question view. Deliberately omits explanation.';

create view public.public_question_options as
select
  id,
  question_id,
  option_label,
  option_text
from public.question_options;

comment on view public.public_question_options is 'Client-facing options view. Deliberately omits is_correct.';

grant select on public.public_questions to anon, authenticated;
grant select on public.public_question_options to anon, authenticated;

-- Defense in depth: make sure no direct grant on the base tables slipped in.
revoke all on public.questions from anon, authenticated;
revoke all on public.question_options from anon, authenticated;

-- ----------------------------------------------------------------------------
-- Stateless grading function
-- ----------------------------------------------------------------------------
-- Input shape (jsonb array):
--   [{"question_id": "<uuid>", "selected_option_id": "<uuid-or-null>"}, ...]
--
-- Called once, at the moment the user clicks "Submit practice" /
-- "Submit test". Computes correctness and returns it — nothing is written
-- to any table, so this satisfies "no attempts/scores/results are stored"
-- by construction, not just by convention.
create function public.grade_practice_attempt(p_answers jsonb)
returns table (
  question_id uuid,
  selected_option_id uuid,
  correct_option_id uuid,
  is_correct boolean,
  explanation text
)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  return query
  select
    ans.question_id,
    ans.selected_option_id,
    correct_opt.id as correct_option_id,
    (ans.selected_option_id is not null and ans.selected_option_id = correct_opt.id) as is_correct,
    q.explanation
  from jsonb_to_recordset(p_answers) as ans(question_id uuid, selected_option_id uuid)
  join public.questions q
    on q.id = ans.question_id
  join public.question_options correct_opt
    on correct_opt.question_id = q.id
   and correct_opt.is_correct = true;
end;
$$;

comment on function public.grade_practice_attempt(jsonb) is
  'Stateless grading: computes correctness for submitted answers and returns it. Writes nothing to any table.';

revoke all on function public.grade_practice_attempt(jsonb) from public;
grant execute on function public.grade_practice_attempt(jsonb) to authenticated;
-- If guest (non-logged-in) practice should also be gradable, also run:
--   grant execute on function public.grade_practice_attempt(jsonb) to anon;
