# Database — Supabase

## Applying the migration

```bash
# One-time setup
supabase login
supabase link --project-ref <your-project-ref>

# Apply
supabase db push
```
Or paste the contents of `migrations/20260826120000_init_schema.sql` into the
Supabase SQL Editor and run it directly.

## What this migration does NOT include

By design, there are no tables for user practice attempts, submitted answers,
scores, or result history. Practice sessions run entirely in frontend state
(`useExamSession`). Grading happens through a database function
(`grade_practice_attempt`) that computes a result on request and writes
nothing to disk.

## Reading content from the frontend

Fetch questions/options through the public views, never the base tables:

```ts
const { data: questions } = await supabase
  .from("public_questions")
  .select("*")
  .eq("paper_id", paperId);

const { data: options } = await supabase
  .from("public_question_options")
  .select("*")
  .in("question_id", questionIds);
```

Neither view exposes `explanation` or `is_correct` — attempting to select
those columns will simply return an error, since the columns don't exist on
the view.

## Grading a completed session

Call the RPC once, when the user submits (mirrors `finalizeSubmit` in
`ExamSession.tsx`):

```ts
const payload = Object.values(answers).map((a) => ({
  question_id: a.questionId,
  selected_option_id: a.selectedOptionId,
}));

const { data: results } = await supabase.rpc("grade_practice_attempt", {
  p_answers: payload,
});
// results: [{ question_id, selected_option_id, correct_option_id, is_correct, explanation }, ...]
```

Merge `results` into the existing `questions`/`answers` state already held by
`ExamSession` to build the Results page's per-question review — no schema
change needed on the frontend types, this is purely additive data.

## Content table reference

| Table | Purpose |
|---|---|
| `categories` | SSC, Banking, Railway, UPSC, State PSC, ... |
| `exams` | SSC CGL, IBPS PO, RRB NTPC, ... |
| `subjects` | Global subject list, reused across exams |
| `exam_subjects` | Which subjects belong to which exam |
| `previous_year_papers` | A specific sitting: exam + year + shift/paper name |
| `questions` | PYQ content, tied to a paper + subject |
| `question_options` | Answer options per question |
| `profiles` | App-facing user data; `role` gates admin writes |

Admin writes (inserting new exams/papers/questions) require a `profiles.role`
of `'admin'` — there's no content-management UI yet, so for now this means
either setting the role directly in the Supabase dashboard or via SQL:

```sql
update public.profiles set role = 'admin' where id = '<your-user-uuid>';
```
