import { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ChevronLeft, ChevronRight, Eraser, Bookmark, CheckCircle } from "lucide-react";
import { ExamMode, FeedbackMode, Question } from "@/types";
import { useExamSession } from "@/hooks/useExamSession";
import { useTimer } from "@/hooks/useTimer";
import { ExamDataError, gradeAttempt } from "@/services/examService";
import SessionHeader from "@/components/exam/SessionHeader";
import QuestionCard from "@/components/exam/QuestionCard";
import QuestionPalette from "@/components/exam/QuestionPalette";
import SubmitModal from "@/components/exam/SubmitModal";
import ProgressBar from "@/components/common/ProgressBar";
import Modal from "@/components/common/Modal";
import Button from "@/components/common/Button";

interface ExamSessionProps {
  mode: ExamMode;
  examName: string;
  subject: string;
  questions: Question[];
  mockDurationMinutes?: number; // only used in mock-test mode
  // "immediate": reveal correctness + explanation as soon as the user checks an answer.
  // "after-submit": never reveal during the session — only on the Results page.
  // Defaults to "after-submit" since that's the safer default for exam-style practice.
  feedbackMode?: FeedbackMode;
}

export default function ExamSession({
  mode,
  examName,
  subject,
  questions,
  mockDurationMinutes = 30,
  feedbackMode = "after-submit",
}: ExamSessionProps) {
  const navigate = useNavigate();
  const [submitModalOpen, setSubmitModalOpen] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [autoSubmitted, setAutoSubmitted] = useState(false);

  const {
    currentIndex,
    currentQuestion,
    currentAnswer,
    answers,
    summary,
    progressPercent,
    visitQuestion,
    selectOption,
    clearResponse,
    toggleMarkForReview,
    checkAnswer,
    goNext,
    goPrevious,
    isFirst,
    isLast,
  } = useExamSession(questions);

  const [autoSubmitPending, setAutoSubmitPending] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const finalizeSubmit = useCallback(
    async (elapsedSeconds: number) => {
      // Grading happens against the secure grade_practice_attempt() database
      // function — never by comparing against a correctOptionId in the
      // browser, since Supabase-backed questions never carry one. Nothing
      // about this attempt (answers, score, history) is written to any
      // table; the graded result only ever lives in this navigation's
      // router state, in memory.
      setSubmitError(null);
      setSubmitting(true);
      try {
        const graded = await gradeAttempt(questions, answers);
        navigate(`/results/session-${Date.now()}`, {
          state: {
            examName,
            subject,
            mode,
            total: questions.length,
            unanswered: summary.notAnswered + summary.notVisited,
            timeSpentSeconds: elapsedSeconds,
            questions,
            answers,
            graded,
          },
        });
      } catch (err) {
        setSubmitting(false);
        setSubmitError(
          err instanceof ExamDataError
            ? err.message
            : "Could not submit your answers. Please check your connection and try again."
        );
      }
    },
    [answers, questions, mode, examName, subject, summary, navigate]
  );

  const handleTimerExpire = useCallback(() => {
    setAutoSubmitPending(true);
  }, []);

  const { seconds: timerSeconds } = useTimer({
    mode: mode === "mock-test" ? "countdown" : "count-up",
    durationSeconds: mockDurationMinutes * 60,
    onExpire: mode === "mock-test" ? handleTimerExpire : undefined,
  });

  // Fire the actual submit exactly once, right after the countdown hits zero,
  // so the payload's timeSpentSeconds reflects the full mock duration.
  useEffect(() => {
    if (autoSubmitPending && !autoSubmitted) {
      setAutoSubmitted(true);
      setSubmitModalOpen(true); // surfaces a retry option here if grading fails
      finalizeSubmit(mockDurationMinutes * 60);
    }
  }, [autoSubmitPending, autoSubmitted, finalizeSubmit, mockDurationMinutes]);

  if (!currentQuestion) {
    return (
      <div className="min-h-screen flex items-center justify-center text-slate">
        No questions available for this session.
      </div>
    );
  }

  // "Check answer" is only meaningful when feedback is immediate — in
  // after-submit sessions there's nothing to check mid-session, so this is
  // always false and the button never renders.
  const canCheck =
    feedbackMode === "immediate" && !!currentAnswer.selectedOptionId && !currentAnswer.checked;

  return (
    <div className="min-h-screen flex flex-col bg-paper">
      <SessionHeader
        examName={examName}
        subject={subject}
        mode={mode}
        currentIndex={currentIndex}
        total={questions.length}
        timerSeconds={timerSeconds}
        onOpenPalette={() => setPaletteOpen(true)}
        onSubmit={() => setSubmitModalOpen(true)}
      />

      <div className="max-w-6xl w-full mx-auto px-4 sm:px-6 pt-4">
        <ProgressBar percent={progressPercent} label="Progress" />
      </div>

      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-6 grid lg:grid-cols-[1fr_280px] gap-6 items-start">
        {/* Question panel */}
        <div className="pb-24 lg:pb-0">
          <QuestionCard
            question={currentQuestion}
            answer={currentAnswer}
            feedbackMode={feedbackMode}
            onSelectOption={selectOption}
            onToggleMark={toggleMarkForReview}
          />
        </div>

        {/* Desktop palette sidebar */}
        <aside className="hidden lg:block sticky top-24 bg-white rounded-2xl border border-ink-navy/10 p-5">
          <h3 className="font-display text-sm font-semibold text-ink-navy mb-4">
            Question palette
          </h3>
          <QuestionPalette
            questions={questions}
            answers={answers}
            currentIndex={currentIndex}
            onJump={visitQuestion}
            summary={summary}
          />
        </aside>
      </main>

      {/* Sticky action bar */}
      <div className="sticky bottom-0 bg-white border-t border-ink-navy/10 px-4 sm:px-6 py-3">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-2 flex-wrap">
          <Button variant="outline" size="sm" onClick={goPrevious} disabled={isFirst}>
            <ChevronLeft className="w-4 h-4" /> Previous
          </Button>

          <div className="flex items-center gap-2 flex-wrap justify-end flex-1 sm:flex-initial">
            <Button
              variant="ghost"
              size="sm"
              onClick={clearResponse}
              disabled={!currentAnswer.selectedOptionId}
            >
              <Eraser className="w-4 h-4" /> Clear
            </Button>

            {mode === "mock-test" && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  toggleMarkForReview();
                  goNext();
                }}
              >
                <Bookmark className="w-4 h-4" /> Mark & Next
              </Button>
            )}

            {canCheck && (
              <Button variant="secondary" size="sm" onClick={checkAnswer}>
                <CheckCircle className="w-4 h-4" /> Check answer
              </Button>
            )}

            {!canCheck && (
              <Button
                variant="primary"
                size="sm"
                onClick={isLast ? () => setSubmitModalOpen(true) : goNext}
              >
                {isLast ? "Finish" : mode === "mock-test" ? "Save & Next" : "Next"}
                {!isLast && <ChevronRight className="w-4 h-4" />}
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Mobile palette sheet */}
      <Modal open={paletteOpen} onClose={() => setPaletteOpen(false)} title="Question palette">
        <QuestionPalette
          questions={questions}
          answers={answers}
          currentIndex={currentIndex}
          onJump={(index) => {
            visitQuestion(index);
            setPaletteOpen(false);
          }}
          summary={summary}
        />
      </Modal>

      <SubmitModal
        open={submitModalOpen}
        onClose={() => setSubmitModalOpen(false)}
        onConfirm={() => finalizeSubmit(timerSeconds)}
        summary={summary}
        mode={mode}
        submitting={submitting}
        submitError={submitError}
      />
    </div>
  );
}
