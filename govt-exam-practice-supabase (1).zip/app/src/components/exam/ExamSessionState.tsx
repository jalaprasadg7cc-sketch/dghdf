import { Link } from "react-router-dom";
import { AlertTriangle, Loader2, Inbox } from "lucide-react";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import Button from "@/components/common/Button";

interface ExamSessionStateProps {
  loading: boolean;
  error: string | null;
  emptyMessage: string | null;
  backTo: string;
  loadingTitle?: string;
  loadingMessage?: string;
  emptyTitle?: string;
}

// Covers all three non-happy-path states for a practice/mock-test session:
// still loading from Supabase, a failed request, or a paper with zero
// questions — without ever crashing the app or leaving a blank screen.
// Reused as-is by the exam/paper browsing pages, which hit the same three
// states while loading from the same Supabase tables.
export default function ExamSessionState({
  loading,
  error,
  emptyMessage,
  backTo,
  loadingTitle = "Loading questions…",
  loadingMessage = "Fetching this paper from the question bank.",
  emptyTitle = "No questions yet",
}: ExamSessionStateProps) {
  return (
    <div className="min-h-screen flex flex-col bg-paper">
      <Navbar />
      <main className="flex-1 flex items-center justify-center px-5">
        <div className="text-center max-w-md">
          {loading && (
            <>
              <Loader2 className="w-8 h-8 text-marigold-dark animate-spin mx-auto mb-4" />
              <h1 className="font-display text-2xl font-semibold text-ink-navy mb-2">
                {loadingTitle}
              </h1>
              <p className="text-slate">{loadingMessage}</p>
            </>
          )}

          {!loading && error && (
            <>
              <AlertTriangle className="w-8 h-8 text-crimson mx-auto mb-4" />
              <h1 className="font-display text-2xl font-semibold text-ink-navy mb-2">
                Couldn't load this session
              </h1>
              <p className="text-slate mb-6">{error}</p>
              <div className="flex gap-3 justify-center">
                <Button variant="outline" size="sm" onClick={() => window.location.reload()}>
                  Try again
                </Button>
                <Link to={backTo}>
                  <Button variant="primary" size="sm">
                    Back to exam
                  </Button>
                </Link>
              </div>
            </>
          )}

          {!loading && !error && emptyMessage && (
            <>
              <Inbox className="w-8 h-8 text-slate mx-auto mb-4" />
              <h1 className="font-display text-2xl font-semibold text-ink-navy mb-2">
                {emptyTitle}
              </h1>
              <p className="text-slate mb-6">{emptyMessage}</p>
              <Link to={backTo}>
                <Button variant="primary" size="sm">
                  Choose another paper
                </Button>
              </Link>
            </>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}
