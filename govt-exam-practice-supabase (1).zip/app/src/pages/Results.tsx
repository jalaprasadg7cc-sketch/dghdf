import { Link, useLocation } from "react-router-dom";
import { CheckCircle2, XCircle, MinusCircle, ArrowLeft } from "lucide-react";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import Button from "@/components/common/Button";
import { ExamMode, GradedQuestionResult, Question, UserAnswer } from "@/types";
import { formatCountUp } from "@/utils/time";

interface ResultsLocationState {
  examName: string;
  subject: string;
  mode: ExamMode;
  total: number;
  unanswered: number;
  timeSpentSeconds: number;
  questions: Question[];
  answers: Record<string, UserAnswer>;
  graded: GradedQuestionResult[];
}

type RowStatus = "Correct" | "Incorrect" | "Not Answered";

function statusFor(graded: GradedQuestionResult | undefined): RowStatus {
  if (!graded || !graded.selectedOptionId) return "Not Answered";
  return graded.isCorrect ? "Correct" : "Incorrect";
}

const statusStyles: Record<RowStatus, { text: string; bg: string; icon: JSX.Element }> = {
  Correct: {
    text: "text-emerald",
    bg: "bg-emerald-light border-emerald/30",
    icon: <CheckCircle2 className="w-4 h-4" />,
  },
  Incorrect: {
    text: "text-crimson",
    bg: "bg-crimson-light border-crimson/30",
    icon: <XCircle className="w-4 h-4" />,
  },
  "Not Answered": {
    text: "text-slate",
    bg: "bg-ink-navy/5 border-ink-navy/10",
    icon: <MinusCircle className="w-4 h-4" />,
  },
};

// This page is intentionally session-only: it reads the graded result out of
// router state (set once, right after Submit) and never persists or
// re-fetches anything. A refresh loses this state on purpose — no practice
// attempt, answer, or score is ever written to the database.
export default function Results() {
  const location = useLocation();
  const state = location.state as ResultsLocationState | null;

  if (!state) {
    return (
      <div className="min-h-screen flex flex-col bg-paper">
        <Navbar />
        <main className="flex-1 flex items-center justify-center px-5">
          <div className="text-center max-w-md">
            <p className="font-mono text-xs uppercase tracking-widest text-marigold-dark mb-3">
              No result to show
            </p>
            <h1 className="font-display text-3xl font-semibold text-ink-navy mb-3">
              This result is no longer available
            </h1>
            <p className="text-slate mb-6">
              Results are temporary and only shown right after you submit — they aren't stored,
              so refreshing or revisiting this link clears them. Start a new session to see a
              fresh result.
            </p>
            <Link to="/exams">
              <Button variant="primary" size="md">
                Browse exams
              </Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const { examName, subject, mode, total, timeSpentSeconds, questions, answers, graded } = state;

  const gradedByQuestion = new Map(graded.map((g) => [g.questionId, g]));
  const correctCount = graded.filter((g) => g.isCorrect).length;
  const incorrectCount = graded.filter((g) => !g.isCorrect && g.selectedOptionId).length;
  const notAnsweredCount = graded.filter((g) => !g.selectedOptionId).length;

  const summaryRows = [
    { label: "Correct", value: correctCount, color: "text-emerald" },
    { label: "Incorrect", value: incorrectCount, color: "text-crimson" },
    { label: "Not answered", value: notAnsweredCount, color: "text-slate" },
    { label: "Total", value: total, color: "text-ink-navy" },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-paper">
      <Navbar />
      <main className="flex-1 max-w-4xl w-full mx-auto px-4 sm:px-6 py-10">
        <p className="font-mono text-xs uppercase tracking-widest text-marigold-dark mb-3">
          {mode === "mock-test" ? "Mock test result" : "Practice result"} · not saved
        </p>
        <h1 className="font-display text-3xl font-semibold text-ink-navy mb-1">{examName}</h1>
        <p className="text-slate mb-8">
          {subject} · Time taken {formatCountUp(timeSpentSeconds)}
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-10">
          {summaryRows.map((row) => (
            <div key={row.label} className="bg-white rounded-2xl border border-ink-navy/10 px-4 py-4">
              <p className="text-xs text-slate mb-1 font-sans">{row.label}</p>
              <p className={`text-2xl font-mono font-semibold ${row.color}`}>{row.value}</p>
            </div>
          ))}
        </div>

        <div className="bg-marigold/10 border border-marigold/30 rounded-xl px-4 py-3 mb-8 text-xs text-marigold-dark">
          This result is shown only in this session and is not stored anywhere — closing or
          refreshing this page will clear it.
        </div>

        <h2 className="font-display text-xl font-semibold text-ink-navy mb-4">
          Question-by-question review
        </h2>

        <div className="flex flex-col gap-4">
          {questions.map((question, index) => {
            const g = gradedByQuestion.get(question.id);
            const status = statusFor(g);
            const styles = statusStyles[status];
            const userOption = question.options.find(
              (o) => o.dbOptionId === g?.selectedOptionId
            );
            const correctOption = question.options.find(
              (o) => o.dbOptionId === g?.correctOptionId
            );
            const userAnswer = answers[question.id];

            return (
              <div
                key={question.id}
                className="bg-white rounded-2xl border border-ink-navy/10 p-5 sm:p-6"
              >
                <div className="flex items-start justify-between gap-3 mb-3">
                  <p className="font-mono text-xs text-slate">Question {index + 1}</p>
                  <span
                    className={`inline-flex items-center gap-1.5 text-xs font-sans font-semibold px-2.5 py-1 rounded-full border ${styles.bg} ${styles.text}`}
                  >
                    {styles.icon}
                    {status}
                    {userAnswer?.markedForReview && " · Marked"}
                  </span>
                </div>

                <p className="font-sans text-base text-ink-navy leading-relaxed mb-4">
                  {question.questionText}
                </p>

                <div className="grid sm:grid-cols-2 gap-3 text-sm">
                  <div className="rounded-lg bg-paper px-3 py-2.5">
                    <p className="text-xs text-slate mb-1">Your answer</p>
                    <p className="font-sans text-ink-navy">
                      {userOption ? `${userOption.id}. ${userOption.text}` : "Not answered"}
                    </p>
                  </div>
                  <div className="rounded-lg bg-emerald-light px-3 py-2.5">
                    <p className="text-xs text-emerald mb-1">Correct answer</p>
                    <p className="font-sans text-ink-navy">
                      {correctOption ? `${correctOption.id}. ${correctOption.text}` : "—"}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-10">
          <Link to="/exams" className="inline-flex items-center gap-1.5 text-sm font-semibold text-ink-navy hover:text-marigold-dark">
            <ArrowLeft className="w-4 h-4" /> Back to exams
          </Link>
        </div>
      </main>
      <Footer />
    </div>
  );
}
