import { useParams, useSearchParams } from "react-router-dom";
import ExamSession from "@/components/exam/ExamSession";
import ExamSessionState from "@/components/exam/ExamSessionState";
import { usePaperQuestions } from "@/hooks/usePaperQuestions";

export default function MockTest() {
  const { examId = "rrb-ntpc" } = useParams();
  const [searchParams] = useSearchParams();
  const paperId = searchParams.get("paper");

  const { loading, error, exam, questions } = usePaperQuestions(examId, paperId);

  if (loading || error || questions.length === 0) {
    return (
      <ExamSessionState
        loading={loading}
        error={error}
        emptyMessage={
          !loading && !error ? "No questions are available for this paper yet." : null
        }
        backTo={`/exams/${examId}`}
      />
    );
  }

  return (
    <ExamSession
      mode="mock-test"
      examName={exam?.name ?? "Mock Test"}
      subject={questions[0]?.subject ?? "Full Mock Test"}
      questions={questions}
      mockDurationMinutes={20}
      feedbackMode="after-submit"
    />
  );
}
