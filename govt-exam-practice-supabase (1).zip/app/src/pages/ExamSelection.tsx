import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import ExamSessionState from "@/components/exam/ExamSessionState";
import { DbExam } from "@/types";
import { ExamDataError, fetchExams } from "@/services/examService";

// Category → Exam step of the flow. Reads live data from Supabase
// (categories/exams tables, both public-read) instead of the static
// marketing list used on the Home page.
export default function ExamSelection() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [exams, setExams] = useState<DbExam[]>([]);

  useEffect(() => {
    let cancelled = false;
    fetchExams()
      .then((data) => {
        if (!cancelled) {
          setExams(data);
          setLoading(false);
        }
      })
      .catch((err) => {
        if (!cancelled) {
          setError(err instanceof ExamDataError ? err.message : "Could not load exams.");
          setLoading(false);
        }
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (loading || error) {
    return (
      <ExamSessionState
        loading={loading}
        error={error}
        emptyMessage={null}
        backTo="/"
        loadingTitle="Loading exams…"
        loadingMessage="Fetching exam categories from the database."
      />
    );
  }

  const byCategory = exams.reduce<Record<string, DbExam[]>>((acc, exam) => {
    acc[exam.categoryName] = acc[exam.categoryName] ?? [];
    acc[exam.categoryName].push(exam);
    return acc;
  }, {});

  return (
    <div className="min-h-screen flex flex-col bg-paper">
      <Navbar />
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-12">
        <h1 className="font-display text-3xl font-semibold text-ink-navy mb-2">All exams</h1>
        <p className="text-slate mb-10">Pick an exam to see its previous year papers.</p>

        {exams.length === 0 && (
          <p className="text-slate">No exams have been added yet.</p>
        )}

        {Object.entries(byCategory).map(([category, categoryExams]) => (
          <section key={category || "Uncategorized"} className="mb-10">
            <h2 className="font-display text-lg font-semibold text-ink-navy mb-4">
              {category || "Other"}
            </h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {categoryExams.map((exam) => (
                <Link
                  key={exam.id}
                  to={`/exams/${exam.slug}`}
                  className="group flex flex-col bg-white rounded-2xl p-6 border border-ink-navy/10 transition-all hover:-translate-y-1 hover:shadow-lg"
                >
                  <div className="flex items-start justify-between mb-3">
                    <h3 className="font-display text-xl font-semibold text-ink-navy">
                      {exam.name}
                    </h3>
                    <ArrowUpRight className="w-5 h-5 text-slate group-hover:text-ink-navy transition-colors" />
                  </div>
                  <p className="text-sm text-slate">{exam.fullName}</p>
                  {exam.description && (
                    <p className="text-sm text-slate mt-2 line-clamp-2">{exam.description}</p>
                  )}
                </Link>
              ))}
            </div>
          </section>
        ))}
      </main>
      <Footer />
    </div>
  );
}
