import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { FileText, ListChecks, Timer } from "lucide-react";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import Button from "@/components/common/Button";
import ExamSessionState from "@/components/exam/ExamSessionState";
import { DbExam, DbPaper } from "@/types";
import { ExamDataError, fetchExamBySlug, fetchPapersForExam } from "@/services/examService";

function formatPaperLabel(paper: DbPaper): string {
  const parts = [String(paper.year)];
  if (paper.shift) parts.push(paper.shift);
  return paper.paperName ? `${paper.paperName} — ${parts.join(", ")}` : parts.join(", ");
}

// Exam → Previous Year Paper step of the flow. Fetches the exam and its
// papers from Supabase (both public-read tables) and links each paper to
// the practice/mock-test sessions, which load their questions from the
// safe public views.
export default function ExamDetails() {
  const { examId = "" } = useParams();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [exam, setExam] = useState<DbExam | null>(null);
  const [papers, setPapers] = useState<DbPaper[]>([]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);

    (async () => {
      try {
        const foundExam = await fetchExamBySlug(examId);
        if (!foundExam) throw new ExamDataError(`No exam found for "${examId}".`);
        const foundPapers = await fetchPapersForExam(foundExam.id);
        if (!cancelled) {
          setExam(foundExam);
          setPapers(foundPapers);
          setLoading(false);
        }
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof ExamDataError ? err.message : "Could not load this exam.");
          setLoading(false);
        }
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [examId]);

  if (loading || error) {
    return (
      <ExamSessionState
        loading={loading}
        error={error}
        emptyMessage={null}
        backTo="/exams"
        loadingTitle="Loading exam…"
        loadingMessage="Fetching exam details from the database."
      />
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-paper">
      <Navbar />
      <main className="flex-1 max-w-4xl w-full mx-auto px-4 sm:px-6 py-12">
        <p className="font-mono text-xs uppercase tracking-widest text-marigold-dark mb-3">
          {exam?.categoryName}
        </p>
        <h1 className="font-display text-3xl font-semibold text-ink-navy mb-2">{exam?.name}</h1>
        <p className="text-slate mb-10">{exam?.fullName}</p>

        <h2 className="font-display text-lg font-semibold text-ink-navy mb-4">
          Previous year papers
        </h2>

        {papers.length === 0 ? (
          <p className="text-slate">No papers have been imported for this exam yet.</p>
        ) : (
          <div className="flex flex-col gap-4">
            {papers.map((paper) => (
              <div
                key={paper.id}
                className="bg-white rounded-2xl border border-ink-navy/10 p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4"
              >
                <div className="flex items-center gap-3">
                  <span className="inline-flex w-10 h-10 rounded-lg bg-ink-navy/5 items-center justify-center shrink-0">
                    <FileText className="w-5 h-5 text-ink-navy" />
                  </span>
                  <div>
                    <p className="font-sans font-semibold text-ink-navy">
                      {formatPaperLabel(paper)}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <Link to={`/exams/${examId}/practice?paper=${paper.id}`}>
                    <Button variant="outline" size="sm">
                      <ListChecks className="w-4 h-4" /> Practice
                    </Button>
                  </Link>
                  <Link to={`/exams/${examId}/mock-test?paper=${paper.id}`}>
                    <Button variant="primary" size="sm">
                      <Timer className="w-4 h-4" /> Mock test
                    </Button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}
