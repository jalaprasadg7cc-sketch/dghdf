import { supabase, ensureAuthSession } from "@/lib/supabaseClient";
import {
  DbCategory,
  DbExam,
  DbPaper,
  GradeAnswerInput,
  GradedQuestionResult,
  Question,
  QuestionOption,
  UserAnswer,
} from "@/types";

// Thrown for any Supabase/network failure so pages can show one friendly
// message instead of leaking raw Postgres/fetch errors into the UI.
export class ExamDataError extends Error {
  constructor(message: string, public cause?: unknown) {
    super(message);
    this.name = "ExamDataError";
  }
}

export async function fetchCategories(): Promise<DbCategory[]> {
  const { data, error } = await supabase.from("categories").select("id, name").order("name");
  if (error) throw new ExamDataError("Could not load exam categories.", error);
  return (data ?? []).map((row) => ({ id: row.id, name: row.name }));
}

export async function fetchExams(): Promise<DbExam[]> {
  const { data, error } = await supabase
    .from("exams")
    .select("id, category_id, name, full_name, slug, description, categories(name)")
    .order("name");
  if (error) throw new ExamDataError("Could not load exams.", error);
  return (data ?? []).map((row: any) => ({
    id: row.id,
    categoryId: row.category_id,
    categoryName: row.categories?.name ?? "",
    name: row.name,
    fullName: row.full_name,
    slug: row.slug,
    description: row.description,
  }));
}

export async function fetchExamBySlug(slug: string): Promise<DbExam | null> {
  const { data, error } = await supabase
    .from("exams")
    .select("id, category_id, name, full_name, slug, description, categories(name)")
    .eq("slug", slug)
    .maybeSingle();
  if (error) throw new ExamDataError("Could not load this exam.", error);
  if (!data) return null;
  const row: any = data;
  return {
    id: row.id,
    categoryId: row.category_id,
    categoryName: row.categories?.name ?? "",
    name: row.name,
    fullName: row.full_name,
    slug: row.slug,
    description: row.description,
  };
}

export async function fetchPapersForExam(examId: string): Promise<DbPaper[]> {
  const { data, error } = await supabase
    .from("previous_year_papers")
    .select("id, exam_id, year, appeared_date, shift, paper_name")
    .eq("exam_id", examId)
    .order("appeared_date", { ascending: false });
  if (error) throw new ExamDataError("Could not load previous year papers for this exam.", error);
  return (data ?? []).map((row) => ({
    id: row.id,
    examId: row.exam_id,
    year: row.year,
    appearedDate: row.appeared_date,
    shift: row.shift,
    paperName: row.paper_name,
  }));
}

/**
 * Loads one paper's questions + options from the SAFE PUBLIC VIEWS ONLY
 * (public_questions / public_question_options). These views deliberately
 * omit is_correct and explanation, so the correct answer never reaches the
 * browser before submission — see grade_practice_attempt() for grading.
 */
export async function fetchQuestionsForPaper(
  paperId: string,
  examSlug: string
): Promise<Question[]> {
  const { data: paper, error: paperError } = await supabase
    .from("previous_year_papers")
    .select("id, year")
    .eq("id", paperId)
    .maybeSingle();
  if (paperError) throw new ExamDataError("Could not load the selected paper.", paperError);
  if (!paper) throw new ExamDataError("This paper could not be found.");

  const { data: questionRows, error: questionsError } = await supabase
    .from("public_questions")
    .select("id, paper_id, subject_id, question_text, difficulty, created_at")
    .eq("paper_id", paperId)
    .order("created_at", { ascending: true });
  if (questionsError) throw new ExamDataError("Could not load questions for this paper.", questionsError);

  const questions = questionRows ?? [];
  if (questions.length === 0) return [];

  // Resolved as a separate query rather than a PostgREST embed
  // (subjects(name)) on public_questions — embedding is reliable on base
  // tables (see fetchExams above) but not guaranteed through a view.
  const subjectIds = Array.from(new Set(questions.map((q: any) => q.subject_id)));
  const { data: subjectRows, error: subjectsError } = await supabase
    .from("subjects")
    .select("id, name")
    .in("id", subjectIds);
  if (subjectsError) throw new ExamDataError("Could not load subjects.", subjectsError);
  const subjectNameById = new Map((subjectRows ?? []).map((s) => [s.id, s.name]));

  const questionIds = questions.map((q: any) => q.id);
  const { data: optionRows, error: optionsError } = await supabase
    .from("public_question_options")
    .select("id, question_id, option_label, option_text")
    .in("question_id", questionIds)
    .order("option_label", { ascending: true });
  if (optionsError) throw new ExamDataError("Could not load answer options.", optionsError);

  const optionsByQuestion = new Map<string, QuestionOption[]>();
  (optionRows ?? []).forEach((row: any) => {
    const list = optionsByQuestion.get(row.question_id) ?? [];
    list.push({ id: row.option_label, text: row.option_text, dbOptionId: row.id });
    optionsByQuestion.set(row.question_id, list);
  });

  return questions.map((row: any) => ({
    id: row.id,
    examId: examSlug,
    subject: subjectNameById.get(row.subject_id) ?? "General",
    year: paper.year,
    questionText: row.question_text,
    options: optionsByQuestion.get(row.id) ?? [],
    difficulty: (row.difficulty ?? "Medium") as Question["difficulty"],
  }));
}

/**
 * Sends the user's selected answers to the secure grade_practice_attempt()
 * database function. Correct answers are resolved server-side, against the
 * base tables — the frontend never reads question_options.is_correct
 * directly. Nothing about this attempt is written to any table.
 */
export async function gradeAttempt(
  questions: Question[],
  answers: Record<string, UserAnswer>
): Promise<GradedQuestionResult[]> {
  await ensureAuthSession();

  const payload: GradeAnswerInput[] = questions.map((q) => {
    const answer = answers[q.id];
    const selectedOption = answer?.selectedOptionId
      ? q.options.find((o) => o.id === answer.selectedOptionId)
      : undefined;
    return {
      question_id: q.id,
      selected_option_id: selectedOption?.dbOptionId ?? null,
    };
  });

  const { data, error } = await supabase.rpc("grade_practice_attempt", { p_answers: payload });
  if (error) throw new ExamDataError("Could not grade your submission. Please try again.", error);

  return (data ?? []).map((row: any) => ({
    questionId: row.question_id,
    selectedOptionId: row.selected_option_id,
    correctOptionId: row.correct_option_id,
    isCorrect: row.is_correct,
    explanation: row.explanation,
  }));
}
