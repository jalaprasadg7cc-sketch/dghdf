export type ExamCategory =
  | "SSC"
  | "Banking"
  | "Railway"
  | "UPSC"
  | "State PSC";

export interface Exam {
  id: string;
  name: string;
  fullName: string;
  category: ExamCategory;
  description: string;
  papersCount: number;
  questionsCount: number;
  aspirantsCount: number; // displayed as "aspirants practicing"
  colorAccent: "marigold" | "emerald" | "navy" | "crimson";
  subjects: string[];
}

export interface QuestionOption {
  id: string; // "A" | "B" | "C" | "D" — used for display and as UserAnswer.selectedOptionId
  text: string;
  // Present only for Supabase-backed questions: the real question_options.id
  // (uuid) needed to submit an answer to grade_practice_attempt(). Static/
  // local question data never sets this.
  dbOptionId?: string;
}

export interface Question {
  id: string;
  examId: string;
  subject: string;
  // Not every source has a per-question topic (the current Supabase schema
  // doesn't store one) — optional so QuestionCard can skip the tag.
  topic?: string;
  year: number;
  questionText: string;
  options: QuestionOption[];
  // Hidden by design until the exam is submitted: Supabase-backed questions
  // are fetched from public_questions/public_question_options, which never
  // expose the correct option or explanation. Only Results (after grading)
  // fills these in.
  correctOptionId?: string;
  explanation?: string;
  difficulty: "Easy" | "Medium" | "Hard";
}

// ---- Supabase-backed exam browsing (Category → Exam → Paper) ----

export interface DbCategory {
  id: string;
  name: string;
}

export interface DbExam {
  id: string;
  categoryId: string;
  categoryName: string;
  name: string;
  fullName: string;
  slug: string;
  description: string | null;
}

export interface DbPaper {
  id: string;
  examId: string;
  year: number;
  appearedDate: string | null;
  shift: string | null;
  paperName: string | null;
}

// ---- Grading (grade_practice_attempt) ----

export interface GradeAnswerInput {
  question_id: string;
  selected_option_id: string | null;
}

export interface GradedQuestionResult {
  questionId: string;
  selectedOptionId: string | null;
  correctOptionId: string;
  isCorrect: boolean;
  explanation: string | null;
}

export type ExamMode = "practice" | "mock-test";

// Controls when a question's correctness is revealed to the user:
// "immediate"    — reveal right after the user checks/answers (used sparingly)
// "after-submit" — never reveal during the session; only on the Results page
export type FeedbackMode = "immediate" | "after-submit";

// A question's palette state is derived from independent flags below,
// not a single enum — this is what allows "answered AND marked for review"
// to exist simultaneously, matching real exam interfaces.
export type QuestionPaletteStatus =
  | "not-visited"
  | "not-answered"
  | "answered"
  | "marked-for-review"
  | "answered-marked-for-review";

export interface UserAnswer {
  questionId: string;
  selectedOptionId: string | null;
  visited: boolean;
  markedForReview: boolean;
  checked: boolean; // practice mode: has the user hit "Check Answer"
  timeSpentSeconds: number;
}

export interface SessionSummary {
  total: number;
  answered: number;
  notAnswered: number;
  markedForReview: number;
  notVisited: number;
}

export interface TestResult {
  id: string;
  examId: string;
  examName: string;
  dateTaken: string;
  totalQuestions: number;
  correct: number;
  incorrect: number;
  unanswered: number;
  score: number;
  maxScore: number;
  accuracy: number; // percentage
  timeTakenMinutes: number;
}

export interface TopicPerformance {
  topic: string;
  subject: string;
  accuracy: number;
  questionsAttempted: number;
}
