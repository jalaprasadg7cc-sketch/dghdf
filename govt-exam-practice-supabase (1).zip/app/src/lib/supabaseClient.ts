import { createClient } from "@supabase/supabase-js";

// Read from Vite env vars only — never hardcode keys/URLs here.
// Add these to a local .env file (see .env.example):
//   VITE_SUPABASE_URL=https://<project-ref>.supabase.co
//   VITE_SUPABASE_ANON_KEY=<anon/public key>
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  // Thrown at module load so the failure is loud and obvious in dev,
  // rather than surfacing later as a confusing fetch error.
  console.error(
    "Missing Supabase env vars. Make sure VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY are set in your .env file."
  );
}

export const supabase = createClient(supabaseUrl ?? "", supabaseAnonKey ?? "");

// The grading function (grade_practice_attempt) is granted to the
// `authenticated` Postgres role only — not `anon` — so it can be governed
// by RLS-style role checks in the future without extra work. Since this
// app has no login flow yet, we transparently sign the visitor in as an
// anonymous Supabase Auth user the first time it's needed. This requires
// "Anonymous sign-ins" to be enabled in Supabase Dashboard → Authentication
// → Providers. No schema changes are required for this.
let ensureSessionPromise: Promise<void> | null = null;

export function ensureAuthSession(): Promise<void> {
  if (!ensureSessionPromise) {
    ensureSessionPromise = (async () => {
      const { data } = await supabase.auth.getSession();
      if (data.session) return;

      const { error } = await supabase.auth.signInAnonymously();
      if (error) {
        // Reset so a later retry (e.g. after enabling anonymous sign-ins) can try again.
        ensureSessionPromise = null;
        throw error;
      }
    })();
  }
  return ensureSessionPromise;
}
