import { useEffect, useState } from "react";
import { DbExam, Question } from "@/types";
import {
  ExamDataError,
  fetchExamBySlug,
  fetchPapersForExam,
  fetchQuestionsForPaper,
} from "@/services/examService";

interface UsePaperQuestionsResult {
  loading: boolean;
  error: string | null;
  exam: DbExam | null;
  paperId: string | null;
  questions: Question[];
}

/**
 * Resolves exam slug (+ optional paper id) to a question set, loading from
 * Supabase's safe public views. If no paperId is given, falls back to the
 * most recent previous-year paper available for that exam.
 */
export function usePaperQuestions(examSlug: string, paperId?: string | null): UsePaperQuestionsResult {
  const [state, setState] = useState<UsePaperQuestionsResult>({
    loading: true,
    error: null,
    exam: null,
    paperId: null,
    questions: [],
  });

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setState((prev) => ({ ...prev, loading: true, error: null }));
      try {
        const exam = await fetchExamBySlug(examSlug);
        if (!exam) {
          throw new ExamDataError(`No exam found for "${examSlug}".`);
        }

        let resolvedPaperId = paperId ?? null;
        if (!resolvedPaperId) {
          const papers = await fetchPapersForExam(exam.id);
          if (papers.length === 0) {
            if (!cancelled) {
              setState({ loading: false, error: null, exam, paperId: null, questions: [] });
            }
            return;
          }
          resolvedPaperId = papers[0].id;
        }

        const questions = await fetchQuestionsForPaper(resolvedPaperId, examSlug);
        if (!cancelled) {
          setState({ loading: false, error: null, exam, paperId: resolvedPaperId, questions });
        }
      } catch (err) {
        if (!cancelled) {
          const message =
            err instanceof ExamDataError
              ? err.message
              : "Something went wrong loading questions. Please try again.";
          setState({ loading: false, error: message, exam: null, paperId: null, questions: [] });
        }
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [examSlug, paperId]);

  return state;
}
