import { useCallback, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ChevronLeft, ChevronRight, Eraser, Bookmark, CheckCircle } from "lucide-react";
import { ExamMode, Question } from "@/types";
import { useExamSession } from "@/hooks/useExamSession";
import { useTimer } from "@/hooks/useTimer";
import SessionHeader from "@/components/exam/SessionHeader";
import QuestionCard from "@/components/exam/QuestionCard";
import QuestionPalette from "@/components/exam/QuestionPalette";
import SubmitModal from "@/components/exam/SubmitModal";
import ProgressBar from "@/components/common/ProgressBar";
import Modal from "@/components/common/Modal";
import Button from "@/components/common/Button";

interface ExamSessionProps {
  mode: ExamMode;
  examName: string;
  subject: string;
  questions: Question[];
  mockDurationMinutes?: number; // only used in mock-test mode
}

export default function ExamSession({
  mode,
  examName,
  subject,
  questions,
  mockDurationMinutes = 30,
}: ExamSessionProps) {
  const navigate = useNavigate();
  const [submitModalOpen, setSubmitModalOpen] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [autoSubmitted, setAutoSubmitted] = useState(false);

  const {
    currentIndex,
    currentQuestion,
    currentAnswer,
    answers,
    summary,
    progressPercent,
    visitQuestion,
    selectOption,
    clearResponse,
    toggleMarkForReview,
    checkAnswer,
    goNext,
    goPrevious,
    isFirst,
    isLast,
  } = useExamSession(questions);

  const finalizeSubmit = useCallback(() => {
    // Frontend-only prototype: compute a lightweight result and hand it to the
    // Results page via router state. No backend/persistence at this stage.
    const correct = questions.filter(
      (q) => answers[q.id]?.selectedOptionId === q.correctOptionId
    ).length;

    navigate(`/results/demo-${mode}`, {
      state: {
        examName,
        subject,
        mode,
        total: questions.length,
        correct,
        incorrect: summary.answered - correct,
        unanswered: summary.notAnswered + summary.notVisited,
      },
    });
  }, [answers, questions, mode, examName, subject, summary, navigate]);

  const handleTimerExpire = useCallback(() => {
    if (autoSubmitted) return;
    setAutoSubmitted(true);
    finalizeSubmit();
  }, [autoSubmitted, finalizeSubmit]);

  const { seconds: timerSeconds } = useTimer({
    mode: mode === "mock-test" ? "countdown" : "count-up",
    durationSeconds: mockDurationMinutes * 60,
    onExpire: mode === "mock-test" ? handleTimerExpire : undefined,
  });

  if (!currentQuestion) {
    return (
      <div className="min-h-screen flex items-center justify-center text-slate">
        No questions available for this session.
      </div>
    );
  }

  const canCheck = mode === "practice" && !!currentAnswer.selectedOptionId && !currentAnswer.checked;

  return (
    <div className="min-h-screen flex flex-col bg-paper">
      <SessionHeader
        examName={examName}
        subject={subject}
        mode={mode}
        currentIndex={currentIndex}
        total={questions.length}
        timerSeconds={timerSeconds}
        onOpenPalette={() => setPaletteOpen(true)}
        onSubmit={() => setSubmitModalOpen(true)}
      />

      <div className="max-w-6xl w-full mx-auto px-4 sm:px-6 pt-4">
        <ProgressBar percent={progressPercent} label="Progress" />
      </div>

      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-6 grid lg:grid-cols-[1fr_280px] gap-6 items-start">
        {/* Question panel */}
        <div className="pb-24 lg:pb-0">
          <QuestionCard
            question={currentQuestion}
            answer={currentAnswer}
            mode={mode}
            onSelectOption={selectOption}
            onToggleMark={toggleMarkForReview}
          />
        </div>

        {/* Desktop palette sidebar */}
        <aside className="hidden lg:block sticky top-24 bg-white rounded-2xl border border-ink-navy/10 p-5">
          <h3 className="font-display text-sm font-semibold text-ink-navy mb-4">
            Question palette
          </h3>
          <QuestionPalette
            questions={questions}
            answers={answers}
            currentIndex={currentIndex}
            onJump={visitQuestion}
            summary={summary}
          />
        </aside>
      </main>

      {/* Sticky action bar */}
      <div className="sticky bottom-0 bg-white border-t border-ink-navy/10 px-4 sm:px-6 py-3">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-2 flex-wrap">
          <Button variant="outline" size="sm" onClick={goPrevious} disabled={isFirst}>
            <ChevronLeft className="w-4 h-4" /> Previous
          </Button>

          <div className="flex items-center gap-2 flex-wrap justify-end flex-1 sm:flex-initial">
            <Button
              variant="ghost"
              size="sm"
              onClick={clearResponse}
              disabled={!currentAnswer.selectedOptionId}
            >
              <Eraser className="w-4 h-4" /> Clear
            </Button>

            {mode === "mock-test" && (
              <Button variant="outline" size="sm" onClick={() => { toggleMarkForReview(); goNext(); }}>
                <Bookmark className="w-4 h-4" /> Mark & Next
              </Button>
            )}

            {mode === "practice" && canCheck && (
              <Button variant="secondary" size="sm" onClick={checkAnswer}>
                <CheckCircle className="w-4 h-4" /> Check answer
              </Button>
            )}

            {!(mode === "practice" && canCheck) && (
              <Button
                variant="primary"
                size="sm"
                onClick={isLast ? () => setSubmitModalOpen(true) : goNext}
              >
                {isLast ? "Finish" : mode === "mock-test" ? "Save & Next" : "Next"}
                {!isLast && <ChevronRight className="w-4 h-4" />}
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* Mobile palette sheet */}
      <Modal open={paletteOpen} onClose={() => setPaletteOpen(false)} title="Question palette">
        <QuestionPalette
          questions={questions}
          answers={answers}
          currentIndex={currentIndex}
          onJump={(index) => {
            visitQuestion(index);
            setPaletteOpen(false);
          }}
          summary={summary}
        />
      </Modal>

      <SubmitModal
        open={submitModalOpen}
        onClose={() => setSubmitModalOpen(false)}
        onConfirm={finalizeSubmit}
        summary={summary}
        mode={mode}
      />
    </div>
  );
}
