import { useParams } from "react-router-dom";
import ExamSession from "@/components/exam/ExamSession";
import { getExamById } from "@/data/exams";
import { getQuestionsForExam } from "@/data/questions";

export default function MockTest() {
  const { examId = "ssc-cgl" } = useParams();
  const exam = getExamById(examId);
  const questions = getQuestionsForExam(examId);

  return (
    <ExamSession
      mode="mock-test"
      examName={exam?.name ?? "Mock Test"}
      subject={questions[0]?.subject ?? "Full Mock Test"}
      questions={questions}
      mockDurationMinutes={20}
    />
  );
}
