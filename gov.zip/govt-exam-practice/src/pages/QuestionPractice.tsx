import { useParams } from "react-router-dom";
import ExamSession from "@/components/exam/ExamSession";
import { getExamById } from "@/data/exams";
import { getQuestionsForExam } from "@/data/questions";

export default function QuestionPractice() {
  const { examId = "ssc-cgl" } = useParams();
  const exam = getExamById(examId);
  const questions = getQuestionsForExam(examId);

  return (
    <ExamSession
      mode="practice"
      examName={exam?.name ?? "Practice Session"}
      subject={questions[0]?.subject ?? "General Practice"}
      questions={questions}
    />
  );
}
