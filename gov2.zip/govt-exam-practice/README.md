# PYQ Setu — Government Exam PYQ Practice Platform (Frontend Prototype)

Frontend-only prototype. No backend/database — all data is mocked in `src/data/`.

## Stack
- React 18 + TypeScript
- Vite
- Tailwind CSS
- React Router v6
- lucide-react (icons)

## Getting started
```bash
npm install
npm run dev
```
Then open http://localhost:5173

## Folder structure
```
src/
├── components/
│   ├── layout/     Navbar, Footer
│   ├── common/     Button, Modal, ProgressBar
│   └── exam/       ExamCard, AdmitCardWidget, ExamSession, QuestionCard,
│                   OptionButton, QuestionPalette, SessionHeader, SubmitModal
├── pages/          One file per route (QuestionPractice & MockTest are thin
│                   wrappers around the shared ExamSession engine)
├── hooks/          useExamSession (state engine), useTimer (count-up/countdown)
├── data/           Mock data — the ONLY place with hardcoded content
├── types/          Shared TypeScript interfaces
├── config/         Brand config (site name, tagline)
└── utils/          time.ts — timer formatting
```

## Status
- [x] Project scaffold + routing
- [x] Landing / Home page
- [x] Question Practice page (Practice Mode)
- [x] Mock Test page (Mock Test Mode) — shares the same ExamSession engine
- [ ] Exam Selection page
- [ ] Exam Details page
- [ ] Results page (currently a placeholder; ExamSession already navigates
      here with a score summary via router state, ready for the real build)
- [ ] User Dashboard

## Practice Mode vs Mock Test Mode
Both are powered by one `<ExamSession mode="practice" | "mock-test" />` component
and one `useExamSession` state hook — only the mode prop changes behavior:
- **Practice**: stopwatch counts up, "Check Answer" reveals correct/incorrect +
  explanation instantly, no auto-submit.
- **Mock Test**: countdown timer auto-submits at zero, no feedback until the
  Results page, action bar shows "Save & Next" / "Mark for Review & Next".

The question palette uses 5 independent states (not-visited, not-answered,
answered, marked-for-review, answered-and-marked-for-review) — matching the
real logic used in competitive-exam interfaces, where "answered" and "marked
for review" are independent flags rather than one status.

## Rebranding
Change `SITE_NAME` and `SITE_TAGLINE` in `src/config/site.ts` — nothing else needs to change.
