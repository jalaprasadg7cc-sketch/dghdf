import { Exam } from "@/types";

export const exams: Exam[] = [
  {
    id: "ssc-cgl",
    name: "SSC CGL",
    fullName: "Staff Selection Commission — Combined Graduate Level",
    category: "SSC",
    description:
      "Tier-wise practice covering Quantitative Aptitude, Reasoning, English and General Awareness.",
    papersCount: 42,
    questionsCount: 6800,
    aspirantsCount: 184000,
    colorAccent: "marigold",
    subjects: ["Quantitative Aptitude", "Reasoning", "English", "General Awareness"],
  },
  {
    id: "ibps-po",
    name: "IBPS PO",
    fullName: "Institute of Banking Personnel Selection — Probationary Officer",
    category: "Banking",
    description:
      "Prelims and Mains PYQs on Reasoning, Quant, English and Banking Awareness.",
    papersCount: 35,
    questionsCount: 5400,
    aspirantsCount: 152000,
    colorAccent: "emerald",
    subjects: ["Reasoning", "Quantitative Aptitude", "English", "Banking Awareness"],
  },
  {
    id: "rrb-ntpc",
    name: "RRB NTPC",
    fullName: "Railway Recruitment Board — Non-Technical Popular Categories",
    category: "Railway",
    description:
      "CBT 1 and CBT 2 previous papers on Maths, General Intelligence and General Science.",
    papersCount: 38,
    questionsCount: 6100,
    aspirantsCount: 231000,
    colorAccent: "navy",
    subjects: ["Mathematics", "General Intelligence", "General Science", "General Awareness"],
  },
  {
    id: "upsc-cse",
    name: "UPSC CSE",
    fullName: "Union Public Service Commission — Civil Services Examination",
    category: "UPSC",
    description:
      "Prelims GS Paper I & II PYQs with topic-wise breakdown across Polity, History and Economy.",
    papersCount: 30,
    questionsCount: 4200,
    aspirantsCount: 97000,
    colorAccent: "crimson",
    subjects: ["Polity", "History", "Geography", "Economy", "Environment & Ecology"],
  },
  {
    id: "state-psc",
    name: "State PSC",
    fullName: "State Public Service Commissions (Multi-state)",
    category: "State PSC",
    description:
      "Previous papers across major state PSCs with state-specific GK modules.",
    papersCount: 54,
    questionsCount: 7300,
    aspirantsCount: 143000,
    colorAccent: "marigold",
    subjects: ["State GK", "Polity", "Reasoning", "Quantitative Aptitude"],
  },
];

export const getExamById = (id: string): Exam | undefined =>
  exams.find((exam) => exam.id === id);

export const platformStats = {
  totalQuestions: exams.reduce((sum, e) => sum + e.questionsCount, 0),
  totalAspirants: exams.reduce((sum, e) => sum + e.aspirantsCount, 0),
  totalExams: exams.length,
};
