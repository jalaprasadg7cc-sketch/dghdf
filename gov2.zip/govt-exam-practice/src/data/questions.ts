import { Question } from "@/types";

export const questions: Question[] = [
  {
    id: "q1",
    examId: "ssc-cgl",
    subject: "Quantitative Aptitude",
    topic: "Time, Speed & Distance",
    year: 2023,
    questionText:
      "A train 120 m long crosses a platform in 20 seconds while travelling at 54 km/h. What is the length of the platform?",
    options: [
      { id: "A", text: "180 m" },
      { id: "B", text: "200 m" },
      { id: "C", text: "210 m" },
      { id: "D", text: "240 m" },
    ],
    correctOptionId: "A",
    explanation:
      "Speed = 54 km/h = 15 m/s. Distance covered by the train in 20s = 300 m. This distance equals platform length + train length, so platform length = 300 − 120 = 180 m.",
    difficulty: "Medium",
  },
  {
    id: "q2",
    examId: "ssc-cgl",
    subject: "Quantitative Aptitude",
    topic: "Percentage",
    year: 2022,
    questionText:
      "In an exam, 60% of students passed in Maths and 70% passed in Science. If 50% passed in both subjects, what percentage of students failed in both?",
    options: [
      { id: "A", text: "10%" },
      { id: "B", text: "15%" },
      { id: "C", text: "20%" },
      { id: "D", text: "25%" },
    ],
    correctOptionId: "C",
    explanation:
      "Passed in at least one = 60 + 70 − 50 = 80%. Failed in both = 100 − 80 = 20%.",
    difficulty: "Easy",
  },
  {
    id: "q3",
    examId: "ssc-cgl",
    subject: "Quantitative Aptitude",
    topic: "Simple & Compound Interest",
    year: 2023,
    questionText:
      "What is the compound interest on ₹8,000 for 2 years at 10% per annum, compounded annually?",
    options: [
      { id: "A", text: "₹1,600" },
      { id: "B", text: "₹1,680" },
      { id: "C", text: "₹1,700" },
      { id: "D", text: "₹1,760" },
    ],
    correctOptionId: "B",
    explanation:
      "Amount = 8000 × (1.1)² = 8000 × 1.21 = 9680. CI = 9680 − 8000 = ₹1,680.",
    difficulty: "Medium",
  },
  {
    id: "q4",
    examId: "ssc-cgl",
    subject: "Quantitative Aptitude",
    topic: "Ratio & Proportion",
    year: 2021,
    questionText:
      "The ratio of ages of A and B is 3:5. After 9 years, the ratio becomes 3:4. What is B's current age?",
    options: [
      { id: "A", text: "10 years" },
      { id: "B", text: "12 years" },
      { id: "C", text: "15 years" },
      { id: "D", text: "18 years" },
    ],
    correctOptionId: "C",
    explanation:
      "Let ages be 3x and 5x. (3x+9)/(5x+9) = 3/4 → 12x+36 = 15x+27 → 3x = 9 → x = 3. B's age = 5×3 = 15 years.",
    difficulty: "Hard",
  },
  {
    id: "q5",
    examId: "ssc-cgl",
    subject: "Quantitative Aptitude",
    topic: "Profit & Loss",
    year: 2022,
    questionText:
      "A shopkeeper marks an item 40% above cost price and gives a 25% discount. What is his profit percentage?",
    options: [
      { id: "A", text: "5%" },
      { id: "B", text: "8%" },
      { id: "C", text: "10%" },
      { id: "D", text: "12%" },
    ],
    correctOptionId: "A",
    explanation:
      "Let CP = 100. Marked price = 140. Selling price after 25% discount = 140 × 0.75 = 105. Profit = 5%.",
    difficulty: "Medium",
  },
  {
    id: "q6",
    examId: "ssc-cgl",
    subject: "Quantitative Aptitude",
    topic: "Number System",
    year: 2020,
    questionText:
      "What is the remainder when 1,000 is divided by 37?",
    options: [
      { id: "A", text: "1" },
      { id: "B", text: "2" },
      { id: "C", text: "3" },
      { id: "D", text: "4" },
    ],
    correctOptionId: "A",
    explanation: "37 × 27 = 999, so 1000 ÷ 37 leaves a remainder of 1.",
    difficulty: "Hard",
  },
  {
    id: "q7",
    examId: "ssc-cgl",
    subject: "Quantitative Aptitude",
    topic: "Algebra",
    year: 2023,
    questionText: "If x + 1/x = 5, what is the value of x² + 1/x²?",
    options: [
      { id: "A", text: "21" },
      { id: "B", text: "23" },
      { id: "C", text: "25" },
      { id: "D", text: "27" },
    ],
    correctOptionId: "B",
    explanation: "x² + 1/x² = (x + 1/x)² − 2 = 25 − 2 = 23.",
    difficulty: "Easy",
  },
  {
    id: "q8",
    examId: "ssc-cgl",
    subject: "Quantitative Aptitude",
    topic: "Geometry",
    year: 2021,
    questionText:
      "The area of a circle is equal to the area of a square. If the side of the square is 22 cm, what is the radius of the circle? (use π = 22/7)",
    options: [
      { id: "A", text: "11.5 cm" },
      { id: "B", text: "12.4 cm" },
      { id: "C", text: "13.9 cm" },
      { id: "D", text: "14.2 cm" },
    ],
    correctOptionId: "C",
    explanation:
      "Area of square = 484 cm². πr² = 484 → r² = 484 × 7/22 = 154 → r ≈ 12.4 cm.",
    difficulty: "Medium",
  },
  {
    id: "q9",
    examId: "ssc-cgl",
    subject: "Quantitative Aptitude",
    topic: "Time & Work",
    year: 2022,
    questionText:
      "A can do a piece of work in 12 days and B in 15 days. They work together for 4 days, then A leaves. In how many more days will B finish the remaining work?",
    options: [
      { id: "A", text: "6 days" },
      { id: "B", text: "6.6 days" },
      { id: "C", text: "7 days" },
      { id: "D", text: "8 days" },
    ],
    correctOptionId: "A",
    explanation:
      "A's rate = 1/12/day, B's rate = 1/15/day. Together for 4 days they complete 4×(1/12+1/15) = 4×(9/60) = 3/5 of the work. Remaining = 2/5. B alone finishes this in (2/5) ÷ (1/15) = 6 days.",
    difficulty: "Hard",
  },
  {
    id: "q10",
    examId: "ssc-cgl",
    subject: "Quantitative Aptitude",
    topic: "Averages",
    year: 2020,
    questionText:
      "The average of 5 consecutive odd numbers is 61. What is the largest number?",
    options: [
      { id: "A", text: "63" },
      { id: "B", text: "65" },
      { id: "C", text: "67" },
      { id: "D", text: "69" },
    ],
    correctOptionId: "B",
    explanation:
      "Numbers: 57, 59, 61, 63, 65 (average 61). Largest number is 65.",
    difficulty: "Easy",
  },
  {
    id: "q11",
    examId: "ssc-cgl",
    subject: "Quantitative Aptitude",
    topic: "Mixtures & Alligation",
    year: 2023,
    questionText:
      "In what ratio must water be mixed with milk to gain 20% on selling the mixture at cost price?",
    options: [
      { id: "A", text: "1:5" },
      { id: "B", text: "1:6" },
      { id: "C", text: "1:4" },
      { id: "D", text: "1:3" },
    ],
    correctOptionId: "A",
    explanation:
      "Selling at CP with 20% gain means CP/SP ratio gives water:milk = 20:100 = 1:5.",
    difficulty: "Medium",
  },
  {
    id: "q12",
    examId: "ssc-cgl",
    subject: "Quantitative Aptitude",
    topic: "Trigonometry",
    year: 2021,
    questionText: "What is the value of sin²30° + cos²30°?",
    options: [
      { id: "A", text: "0" },
      { id: "B", text: "0.5" },
      { id: "C", text: "1" },
      { id: "D", text: "2" },
    ],
    correctOptionId: "C",
    explanation: "By the fundamental identity, sin²θ + cos²θ = 1 for any angle θ.",
    difficulty: "Easy",
  },
  {
    id: "q13",
    examId: "ssc-cgl",
    subject: "Quantitative Aptitude",
    topic: "Data Interpretation",
    year: 2022,
    questionText:
      "If a company's revenue grew from ₹40 lakh to ₹58 lakh in a year, what was the percentage growth?",
    options: [
      { id: "A", text: "35%" },
      { id: "B", text: "40%" },
      { id: "C", text: "45%" },
      { id: "D", text: "50%" },
    ],
    correctOptionId: "C",
    explanation: "Growth = (58−40)/40 × 100 = 18/40 × 100 = 45%.",
    difficulty: "Medium",
  },
  {
    id: "q14",
    examId: "ssc-cgl",
    subject: "Quantitative Aptitude",
    topic: "Number System",
    year: 2023,
    questionText: "How many prime numbers are there between 1 and 30?",
    options: [
      { id: "A", text: "8" },
      { id: "B", text: "9" },
      { id: "C", text: "10" },
      { id: "D", text: "11" },
    ],
    correctOptionId: "C",
    explanation:
      "Primes: 2,3,5,7,11,13,17,19,23,29 — that's 10 primes between 1 and 30.",
    difficulty: "Easy",
  },
  {
    id: "q15",
    examId: "ssc-cgl",
    subject: "Quantitative Aptitude",
    topic: "Boats & Streams",
    year: 2020,
    questionText:
      "A boat covers 32 km downstream in 4 hours and returns upstream in 8 hours. What is the speed of the stream?",
    options: [
      { id: "A", text: "1 km/h" },
      { id: "B", text: "1.5 km/h" },
      { id: "C", text: "2 km/h" },
      { id: "D", text: "2.5 km/h" },
    ],
    correctOptionId: "C",
    explanation:
      "Downstream speed = 32/4 = 8 km/h. Upstream speed = 32/8 = 4 km/h. Stream speed = (8−4)/2 = 2 km/h.",
    difficulty: "Medium",
  },
];

export const getQuestionsForExam = (examId: string): Question[] => {
  const matched = questions.filter((q) => q.examId === examId);
  return matched.length > 0 ? matched : questions; // fallback so no exam ever hits an empty session
};
