import { useEffect, useRef, useState } from "react";

interface UseTimerOptions {
  mode: "count-up" | "countdown";
  durationSeconds?: number; // required for countdown
  onExpire?: () => void;
  paused?: boolean;
}

/**
 * A single timer hook that powers both:
 * - Practice Mode: count-up stopwatch, no ceiling, no auto-submit
 * - Mock Test Mode: countdown from durationSeconds, calls onExpire once at zero
 */
export function useTimer({ mode, durationSeconds = 0, onExpire, paused = false }: UseTimerOptions) {
  const [seconds, setSeconds] = useState(mode === "countdown" ? durationSeconds : 0);
  const expiredRef = useRef(false);

  useEffect(() => {
    if (paused) return;

    const id = setInterval(() => {
      setSeconds((prev) => {
        if (mode === "count-up") return prev + 1;

        // countdown
        if (prev <= 1) {
          if (!expiredRef.current) {
            expiredRef.current = true;
            onExpire?.();
          }
          clearInterval(id);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [paused, mode]);

  return { seconds };
}
