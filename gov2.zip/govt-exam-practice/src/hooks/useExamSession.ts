import { useMemo, useState } from "react";
import { Question, QuestionPaletteStatus, SessionSummary, UserAnswer } from "@/types";

function createInitialAnswers(questions: Question[]): Record<string, UserAnswer> {
  const map: Record<string, UserAnswer> = {};
  questions.forEach((q) => {
    map[q.id] = {
      questionId: q.id,
      selectedOptionId: null,
      visited: false,
      markedForReview: false,
      checked: false,
      timeSpentSeconds: 0,
    };
  });
  return map;
}

export function paletteStatusFor(answer: UserAnswer | undefined): QuestionPaletteStatus {
  if (!answer || !answer.visited) return "not-visited";
  if (answer.markedForReview && answer.selectedOptionId) return "answered-marked-for-review";
  if (answer.markedForReview) return "marked-for-review";
  if (answer.selectedOptionId) return "answered";
  return "not-answered";
}

export function useExamSession(questions: Question[]) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, UserAnswer>>(() => {
    const initial = createInitialAnswers(questions);
    // First question is visited the moment the session opens
    if (questions[0]) initial[questions[0].id].visited = true;
    return initial;
  });

  const currentQuestion = questions[currentIndex];
  const currentAnswer = answers[currentQuestion?.id];

  const visitQuestion = (index: number) => {
    const q = questions[index];
    if (!q) return;
    setCurrentIndex(index);
    setAnswers((prev) => ({
      ...prev,
      [q.id]: { ...prev[q.id], visited: true },
    }));
  };

  const selectOption = (optionId: string) => {
    if (!currentQuestion) return;
    setAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: {
        ...prev[currentQuestion.id],
        selectedOptionId: optionId,
        // changing the answer after checking should re-hide feedback
        checked: false,
      },
    }));
  };

  const clearResponse = () => {
    if (!currentQuestion) return;
    setAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: {
        ...prev[currentQuestion.id],
        selectedOptionId: null,
        checked: false,
      },
    }));
  };

  const toggleMarkForReview = () => {
    if (!currentQuestion) return;
    setAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: {
        ...prev[currentQuestion.id],
        markedForReview: !prev[currentQuestion.id].markedForReview,
      },
    }));
  };

  const checkAnswer = () => {
    if (!currentQuestion) return;
    setAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: { ...prev[currentQuestion.id], checked: true },
    }));
  };

  const goNext = () => {
    if (currentIndex < questions.length - 1) visitQuestion(currentIndex + 1);
  };

  const goPrevious = () => {
    if (currentIndex > 0) visitQuestion(currentIndex - 1);
  };

  const summary: SessionSummary = useMemo(() => {
    const values = Object.values(answers);
    return {
      total: questions.length,
      answered: values.filter((a) => a.selectedOptionId).length,
      notAnswered: values.filter((a) => a.visited && !a.selectedOptionId).length,
      markedForReview: values.filter((a) => a.markedForReview).length,
      notVisited: values.filter((a) => !a.visited).length,
    };
  }, [answers, questions.length]);

  const progressPercent =
    questions.length === 0 ? 0 : Math.round((summary.answered / questions.length) * 100);

  return {
    currentIndex,
    currentQuestion,
    currentAnswer,
    answers,
    summary,
    progressPercent,
    visitQuestion,
    selectOption,
    clearResponse,
    toggleMarkForReview,
    checkAnswer,
    goNext,
    goPrevious,
    isFirst: currentIndex === 0,
    isLast: currentIndex === questions.length - 1,
  };
}
