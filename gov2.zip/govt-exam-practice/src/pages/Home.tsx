import { Link } from "react-router-dom";
import {
  Search,
  Timer,
  LineChart,
  Bookmark,
  Smartphone,
  ListChecks,
  ArrowRight,
} from "lucide-react";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import Button from "@/components/common/Button";
import ExamCard from "@/components/exam/ExamCard";
import AdmitCardWidget from "@/components/exam/AdmitCardWidget";
import { exams, platformStats } from "@/data/exams";

const features = [
  {
    icon: ListChecks,
    title: "Interactive practice",
    description:
      "Answer real previous-year questions one at a time, get instant feedback, no more scrolling PDFs to find the answer key.",
  },
  {
    icon: Timer,
    title: "Full mock tests",
    description:
      "Simulate the real exam with a timer, section-wise navigation and auto-submit — just like the actual test window.",
  },
  {
    icon: LineChart,
    title: "Performance tracking",
    description:
      "See your accuracy by subject and topic over time, so you know exactly what to revise next.",
  },
  {
    icon: Bookmark,
    title: "Bookmark & review",
    description:
      "Save tricky questions as you go and come back to them in a dedicated review list before your exam.",
  },
  {
    icon: Search,
    title: "Topic-wise filters",
    description:
      "Drill into a single topic, like Time & Work or Modern History, instead of practicing at random.",
  },
  {
    icon: Smartphone,
    title: "Built for mobile",
    description:
      "Practice on the metro or between classes — every screen is designed mobile-first, not squeezed in afterward.",
  },
];

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-paper">
      <Navbar />

      <main className="flex-1">
        {/* Hero */}
        <section className="max-w-7xl mx-auto px-5 sm:px-8 pt-14 pb-20 grid lg:grid-cols-2 gap-14 items-center">
          <div>
            <p className="inline-flex items-center gap-2 text-xs font-sans font-semibold uppercase tracking-widest text-marigold-dark bg-marigold/15 px-3 py-1.5 rounded-full mb-6">
              5 exam categories · {platformStats.totalQuestions.toLocaleString()}+ questions
            </p>
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-semibold leading-[1.08] text-ink-navy mb-6">
              Previous year papers,{" "}
              <span className="italic font-medium">actually practiced</span> —
              not just downloaded.
            </h1>
            <p className="text-lg text-slate max-w-xl mb-8 leading-relaxed">
              Stop hunting for PDF answer keys. Practice real SSC, Banking,
              Railway, UPSC and State exam questions one at a time, sit full
              mock tests, and track exactly where you're losing marks.
            </p>

            <form
              role="search"
              className="flex flex-col sm:flex-row gap-3 mb-8"
              onSubmit={(e) => e.preventDefault()}
            >
              <label htmlFor="exam-search" className="sr-only">
                Search for an exam
              </label>
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate absolute left-4 top-1/2 -translate-y-1/2" />
                <input
                  id="exam-search"
                  type="text"
                  placeholder="Search SSC CGL, IBPS PO, UPSC..."
                  className="w-full pl-11 pr-4 py-3.5 rounded-lg border border-ink-navy/15 bg-white font-sans text-sm placeholder:text-slate/70 focus:outline-none focus:ring-2 focus:ring-marigold"
                />
              </div>
              <Button type="submit" variant="primary" size="md">
                Find my exam
              </Button>
            </form>

            <div className="flex items-center gap-8 font-mono text-sm text-slate">
              <div>
                <p className="text-ink-navy font-semibold text-xl">
                  {(platformStats.totalAspirants / 1000).toFixed(0)}k+
                </p>
                <p className="text-xs">aspirants practicing</p>
              </div>
              <div>
                <p className="text-ink-navy font-semibold text-xl">
                  {platformStats.totalExams}
                </p>
                <p className="text-xs">exam categories</p>
              </div>
              <div>
                <p className="text-ink-navy font-semibold text-xl">Free</p>
                <p className="text-xs">to start practicing</p>
              </div>
            </div>
          </div>

          <AdmitCardWidget />
        </section>

        {/* Popular exams */}
        <section className="max-w-7xl mx-auto px-5 sm:px-8 py-16 border-t border-ink-navy/10">
          <div className="flex items-end justify-between mb-8 gap-4 flex-wrap">
            <div>
              <h2 className="font-display text-3xl font-semibold text-ink-navy mb-2">
                Popular government exams
              </h2>
              <p className="text-slate">
                Jump straight into the exam you're preparing for.
              </p>
            </div>
            <Link
              to="/exams"
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-ink-navy hover:text-marigold-dark transition-colors"
            >
              View all exams <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {exams.map((exam) => (
              <ExamCard key={exam.id} exam={exam} />
            ))}
          </div>
        </section>

        {/* Features */}
        <section className="bg-ink-navy py-20">
          <div className="max-w-7xl mx-auto px-5 sm:px-8">
            <div className="max-w-xl mb-12">
              <h2 className="font-display text-3xl font-semibold text-paper mb-3">
                Built for how aspirants actually study
              </h2>
              <p className="text-paper/60">
                Every feature exists to replace a habit that PDF practice
                makes harder than it should be.
              </p>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {features.map((feature) => {
                const Icon = feature.icon;
                return (
                  <div
                    key={feature.title}
                    className="bg-navy-light rounded-2xl p-6 border border-paper/10"
                  >
                    <span className="inline-flex w-10 h-10 rounded-lg bg-marigold/20 items-center justify-center mb-4">
                      <Icon className="w-5 h-5 text-marigold" />
                    </span>
                    <h3 className="font-sans text-base font-semibold text-paper mb-2">
                      {feature.title}
                    </h3>
                    <p className="text-sm text-paper/60 leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="max-w-7xl mx-auto px-5 sm:px-8 py-20">
          <div className="relative bg-marigold rounded-3xl px-8 sm:px-16 py-14 text-center overflow-hidden">
            <div className="absolute inset-0 bg-perforation opacity-10 pointer-events-none" />
            <h2 className="font-display text-3xl sm:text-4xl font-semibold text-ink-navy mb-4 relative">
              Your next mock test is two clicks away
            </h2>
            <p className="text-ink-navy/70 max-w-lg mx-auto mb-8 relative">
              Pick an exam, start with a free practice set, and see your
              first performance report today.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center relative">
              <Button variant="secondary" size="lg">
                Start practicing free
              </Button>
              <Button variant="outline" size="lg" className="border-ink-navy">
                Browse all exams
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
