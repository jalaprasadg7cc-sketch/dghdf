import { Routes, Route } from "react-router-dom";
import Home from "@/pages/Home";
import ExamSelection from "@/pages/ExamSelection";
import ExamDetails from "@/pages/ExamDetails";
import QuestionPractice from "@/pages/QuestionPractice";
import MockTest from "@/pages/MockTest";
import Results from "@/pages/Results";
import Dashboard from "@/pages/Dashboard";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/exams" element={<ExamSelection />} />
      <Route path="/exams/:examId" element={<ExamDetails />} />
      <Route path="/exams/:examId/practice" element={<QuestionPractice />} />
      <Route path="/exams/:examId/mock-test" element={<MockTest />} />
      <Route path="/results/:resultId" element={<Results />} />
      <Route path="/dashboard" element={<Dashboard />} />
    </Routes>
  );
}
