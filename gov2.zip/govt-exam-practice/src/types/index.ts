export type ExamCategory =
  | "SSC"
  | "Banking"
  | "Railway"
  | "UPSC"
  | "State PSC";

export interface Exam {
  id: string;
  name: string;
  fullName: string;
  category: ExamCategory;
  description: string;
  papersCount: number;
  questionsCount: number;
  aspirantsCount: number; // displayed as "aspirants practicing"
  colorAccent: "marigold" | "emerald" | "navy" | "crimson";
  subjects: string[];
}

export interface QuestionOption {
  id: string; // "A" | "B" | "C" | "D"
  text: string;
}

export interface Question {
  id: string;
  examId: string;
  subject: string;
  topic: string;
  year: number;
  questionText: string;
  options: QuestionOption[];
  correctOptionId: string;
  explanation: string;
  difficulty: "Easy" | "Medium" | "Hard";
}

export type ExamMode = "practice" | "mock-test";

// Controls when a question's correctness is revealed to the user:
// "immediate"    — reveal right after the user checks/answers (used sparingly)
// "after-submit" — never reveal during the session; only on the Results page
export type FeedbackMode = "immediate" | "after-submit";

// A question's palette state is derived from independent flags below,
// not a single enum — this is what allows "answered AND marked for review"
// to exist simultaneously, matching real exam interfaces.
export type QuestionPaletteStatus =
  | "not-visited"
  | "not-answered"
  | "answered"
  | "marked-for-review"
  | "answered-marked-for-review";

export interface UserAnswer {
  questionId: string;
  selectedOptionId: string | null;
  visited: boolean;
  markedForReview: boolean;
  checked: boolean; // practice mode: has the user hit "Check Answer"
  timeSpentSeconds: number;
}

export interface SessionSummary {
  total: number;
  answered: number;
  notAnswered: number;
  markedForReview: number;
  notVisited: number;
}

export interface TestResult {
  id: string;
  examId: string;
  examName: string;
  dateTaken: string;
  totalQuestions: number;
  correct: number;
  incorrect: number;
  unanswered: number;
  score: number;
  maxScore: number;
  accuracy: number; // percentage
  timeTakenMinutes: number;
}

export interface TopicPerformance {
  topic: string;
  subject: string;
  accuracy: number;
  questionsAttempted: number;
}
