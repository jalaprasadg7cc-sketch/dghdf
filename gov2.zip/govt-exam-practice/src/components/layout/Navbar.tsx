import { useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { Menu, X, GraduationCap } from "lucide-react";
import { SITE_NAME } from "@/config/site";
import Button from "@/components/common/Button";

const navLinks = [
  { to: "/exams", label: "Exams" },
  { to: "/exams", label: "Mock Tests" },
  { to: "/dashboard", label: "Dashboard" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-paper/95 backdrop-blur border-b border-ink-navy/10">
      <nav className="max-w-7xl mx-auto px-5 sm:px-8 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 shrink-0" aria-label={`${SITE_NAME} home`}>
          <span className="w-9 h-9 rounded-lg bg-ink-navy flex items-center justify-center">
            <GraduationCap className="w-5 h-5 text-marigold" strokeWidth={2.2} />
          </span>
          <span className="font-display text-xl font-semibold tracking-tight">
            {SITE_NAME}
          </span>
        </Link>

        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <NavLink
              key={link.label}
              to={link.to}
              className={({ isActive }) =>
                `font-sans text-sm font-medium transition-colors ${
                  isActive ? "text-ink-navy" : "text-slate hover:text-ink-navy"
                }`
              }
            >
              {link.label}
            </NavLink>
          ))}
        </div>

        <div className="hidden md:flex items-center gap-3">
          <Button variant="ghost" size="sm">
            Log in
          </Button>
          <Button variant="primary" size="sm">
            Start practicing free
          </Button>
        </div>

        <button
          className="md:hidden p-2 -mr-2"
          onClick={() => setOpen((v) => !v)}
          aria-label={open ? "Close menu" : "Open menu"}
          aria-expanded={open}
        >
          {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </nav>

      {open && (
        <div className="md:hidden border-t border-ink-navy/10 bg-paper px-5 pb-5 pt-3 flex flex-col gap-4">
          {navLinks.map((link) => (
            <Link
              key={link.label}
              to={link.to}
              className="font-sans text-base font-medium text-ink-navy"
              onClick={() => setOpen(false)}
            >
              {link.label}
            </Link>
          ))}
          <div className="flex flex-col gap-2 pt-2">
            <Button variant="outline" size="sm">
              Log in
            </Button>
            <Button variant="primary" size="sm">
              Start practicing free
            </Button>
          </div>
        </div>
      )}
    </header>
  );
}
