import { Link } from "react-router-dom";
import { GraduationCap, Twitter, Instagram, Linkedin } from "lucide-react";
import { SITE_NAME, SITE_TAGLINE } from "@/config/site";

const columns = [
  {
    title: "Exams",
    links: ["SSC CGL", "IBPS PO", "RRB NTPC", "UPSC CSE", "State PSC"],
  },
  {
    title: "Product",
    links: ["Practice Mode", "Mock Tests", "Performance Tracker", "Bookmarks"],
  },
  {
    title: "Company",
    links: ["About Us", "Careers", "Contact", "Blog"],
  },
  {
    title: "Legal",
    links: ["Privacy Policy", "Terms of Service", "Refund Policy"],
  },
];

export default function Footer() {
  return (
    <footer className="bg-ink-navy text-paper/80">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 py-14 grid grid-cols-2 md:grid-cols-6 gap-10">
        <div className="col-span-2">
          <Link to="/" className="flex items-center gap-2 mb-3">
            <span className="w-8 h-8 rounded-lg bg-marigold flex items-center justify-center">
              <GraduationCap className="w-4 h-4 text-ink-navy" strokeWidth={2.2} />
            </span>
            <span className="font-display text-lg font-semibold text-paper">
              {SITE_NAME}
            </span>
          </Link>
          <p className="text-sm text-paper/60 max-w-xs">{SITE_TAGLINE}</p>
          <div className="flex items-center gap-4 mt-5">
            <Twitter className="w-4 h-4 text-paper/50 hover:text-marigold cursor-pointer" />
            <Instagram className="w-4 h-4 text-paper/50 hover:text-marigold cursor-pointer" />
            <Linkedin className="w-4 h-4 text-paper/50 hover:text-marigold cursor-pointer" />
          </div>
        </div>

        {columns.map((col) => (
          <div key={col.title}>
            <h4 className="font-sans text-sm font-semibold text-paper mb-3">
              {col.title}
            </h4>
            <ul className="space-y-2">
              {col.links.map((link) => (
                <li key={link}>
                  <a
                    href="#"
                    className="text-sm text-paper/60 hover:text-marigold transition-colors"
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="border-t border-paper/10">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-paper/50">
          <p>&copy; {new Date().getFullYear()} {SITE_NAME}. All rights reserved.</p>
          <p>Not affiliated with any government examination body.</p>
        </div>
      </div>
    </footer>
  );
}
