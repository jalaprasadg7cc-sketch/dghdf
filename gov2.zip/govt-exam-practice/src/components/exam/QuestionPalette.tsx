import { Question, QuestionPaletteStatus, SessionSummary, UserAnswer } from "@/types";
import { paletteStatusFor } from "@/hooks/useExamSession";

interface QuestionPaletteProps {
  questions: Question[];
  answers: Record<string, UserAnswer>;
  currentIndex: number;
  onJump: (index: number) => void;
  summary: SessionSummary;
}

const statusStyles: Record<QuestionPaletteStatus, string> = {
  "not-visited": "bg-white border-2 border-ink-navy/20 text-slate",
  "not-answered": "bg-crimson text-white border-2 border-crimson",
  answered: "bg-emerald text-white border-2 border-emerald",
  "marked-for-review": "bg-violet text-white border-2 border-violet",
  "answered-marked-for-review": "bg-emerald text-white border-2 border-emerald",
};

const legendSwatchStyles: Record<QuestionPaletteStatus, string> = {
  "not-visited": "bg-white border-2 border-ink-navy/30",
  "not-answered": "bg-crimson",
  answered: "bg-emerald",
  "marked-for-review": "bg-violet",
  "answered-marked-for-review": "bg-emerald",
};

const legend: { status: QuestionPaletteStatus; label: string }[] = [
  { status: "answered", label: "Answered" },
  { status: "not-answered", label: "Not answered" },
  { status: "not-visited", label: "Not visited" },
  { status: "marked-for-review", label: "Marked for review" },
  { status: "answered-marked-for-review", label: "Answered & marked" },
];

export default function QuestionPalette({
  questions,
  answers,
  currentIndex,
  onJump,
  summary,
}: QuestionPaletteProps) {
  return (
    <div className="flex flex-col h-full">
      <div className="grid grid-cols-5 gap-2 mb-6">
        {questions.map((q, index) => {
          const status = paletteStatusFor(answers[q.id]);
          const isCurrent = index === currentIndex;
          return (
            <button
              key={q.id}
              onClick={() => onJump(index)}
              aria-label={`Question ${index + 1}, ${status.replace(/-/g, " ")}${
                isCurrent ? ", current" : ""
              }`}
              aria-current={isCurrent}
              className={`relative w-full aspect-square rounded-lg font-mono text-xs font-semibold flex items-center justify-center transition-transform hover:scale-105 ${statusStyles[status]} ${
                isCurrent ? "ring-2 ring-marigold ring-offset-2 ring-offset-white" : ""
              }`}
            >
              {index + 1}
              {status === "answered-marked-for-review" && (
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-violet border border-white" />
              )}
            </button>
          );
        })}
      </div>

      <div className="space-y-2 mb-6">
        {legend.map((item) => (
          <div key={item.status} className="flex items-center gap-2.5">
            <span
              className={`relative w-4 h-4 rounded shrink-0 ${legendSwatchStyles[item.status]}`}
            >
              {item.status === "answered-marked-for-review" && (
                <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-violet border border-white" />
              )}
            </span>
            <span className="text-xs text-slate font-sans">{item.label}</span>
          </div>
        ))}
      </div>

      <div className="mt-auto grid grid-cols-2 gap-3 pt-4 border-t border-ink-navy/10 font-mono text-xs">
        <div>
          <p className="text-slate">Answered</p>
          <p className="text-emerald font-semibold text-base">{summary.answered}</p>
        </div>
        <div>
          <p className="text-slate">Not answered</p>
          <p className="text-crimson font-semibold text-base">{summary.notAnswered}</p>
        </div>
        <div>
          <p className="text-slate">Marked</p>
          <p className="text-violet font-semibold text-base">{summary.markedForReview}</p>
        </div>
        <div>
          <p className="text-slate">Not visited</p>
          <p className="text-ink-navy/60 font-semibold text-base">{summary.notVisited}</p>
        </div>
      </div>
    </div>
  );
}
