import { useEffect, useState } from "react";
import { BadgeCheck } from "lucide-react";

function useElapsedTimer() {
  const [seconds, setSeconds] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => clearInterval(id);
  }, []);
  const mm = String(Math.floor(seconds / 60)).padStart(2, "0");
  const ss = String(seconds % 60).padStart(2, "0");
  return `${mm}:${ss}`;
}

export default function AdmitCardWidget() {
  const elapsed = useElapsedTimer();

  return (
    <div className="relative w-full max-w-sm mx-auto">
      {/* Ticket card */}
      <div className="relative bg-white rounded-2xl shadow-xl border border-ink-navy/10 overflow-hidden">
        {/* Top strip */}
        <div className="bg-ink-navy px-6 py-4 flex items-center justify-between">
          <div>
            <p className="text-[10px] uppercase tracking-widest text-marigold font-sans font-semibold">
              Practice Admit Card
            </p>
            <p className="font-display text-lg text-paper font-semibold">SSC CGL — Tier I</p>
          </div>
          <BadgeCheck className="w-6 h-6 text-marigold" />
        </div>

        <div className="grid grid-cols-2 gap-4 px-6 py-5 font-mono text-xs">
          <div>
            <p className="text-slate uppercase tracking-wide text-[10px] mb-1">Roll No.</p>
            <p className="text-ink-navy font-semibold text-sm">2026-QA-04821</p>
          </div>
          <div>
            <p className="text-slate uppercase tracking-wide text-[10px] mb-1">Subject</p>
            <p className="text-ink-navy font-semibold text-sm">Quant. Aptitude</p>
          </div>
          <div>
            <p className="text-slate uppercase tracking-wide text-[10px] mb-1">Question</p>
            <p className="text-ink-navy font-semibold text-sm">12 / 25</p>
          </div>
          <div>
            <p className="text-slate uppercase tracking-wide text-[10px] mb-1">Time Elapsed</p>
            <p className="text-ink-navy font-semibold text-sm tabular-nums">{elapsed}</p>
          </div>
        </div>

        {/* Perforation */}
        <div className="relative h-0 border-t-2 border-dashed border-ink-navy/15 mx-6">
          <span className="absolute -left-9 -top-3 w-6 h-6 rounded-full bg-paper" />
          <span className="absolute -right-9 -top-3 w-6 h-6 rounded-full bg-paper" />
        </div>

        <div className="px-6 py-5">
          <p className="text-[10px] uppercase tracking-widest text-slate font-sans font-semibold mb-2">
            Live preview
          </p>
          <p className="font-sans text-sm text-ink-navy leading-relaxed">
            A train 120m long crosses a platform in 20s at 54 km/h. Find the
            platform length.
          </p>
          <div className="grid grid-cols-2 gap-2 mt-3">
            {["180 m", "200 m", "210 m", "240 m"].map((opt, i) => (
              <div
                key={opt}
                className={`text-xs font-mono px-3 py-2 rounded-lg border ${
                  i === 1
                    ? "border-emerald bg-emerald-light text-emerald font-semibold"
                    : "border-ink-navy/10 text-slate"
                }`}
              >
                {String.fromCharCode(65 + i)}. {opt}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Floating stamp */}
      <div className="absolute -top-4 -right-4 w-16 h-16 rounded-full bg-marigold border-4 border-paper shadow-md flex flex-col items-center justify-center rotate-12">
        <span className="font-display text-[10px] font-bold text-ink-navy leading-none">
          PYQ
        </span>
        <span className="font-display text-[8px] font-bold text-ink-navy leading-none mt-0.5">
          VERIFIED
        </span>
      </div>
    </div>
  );
}
