import { Clock, Grid3x3 } from "lucide-react";
import { ExamMode } from "@/types";
import { formatCountUp, formatCountdown } from "@/utils/time";

interface SessionHeaderProps {
  examName: string;
  subject: string;
  mode: ExamMode;
  currentIndex: number;
  total: number;
  timerSeconds: number;
  onOpenPalette: () => void;
  onSubmit: () => void;
}

export default function SessionHeader({
  examName,
  subject,
  mode,
  currentIndex,
  total,
  timerSeconds,
  onOpenPalette,
  onSubmit,
}: SessionHeaderProps) {
  const isMock = mode === "mock-test";
  const timeLow = isMock && timerSeconds <= 120;

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-ink-navy/10">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="font-display text-sm sm:text-base font-semibold text-ink-navy truncate">
            {examName}
          </p>
          <p className="text-xs text-slate truncate">{subject}</p>
        </div>

        <div className="flex items-center gap-3 sm:gap-5 shrink-0">
          <span className="hidden sm:inline text-xs font-mono text-slate">
            Question <span className="text-ink-navy font-semibold">{currentIndex + 1}</span> /{" "}
            {total}
          </span>

          <span
            className={`inline-flex items-center gap-1.5 font-mono text-sm font-semibold px-3 py-1.5 rounded-lg ${
              timeLow
                ? "bg-crimson-light text-crimson animate-pulse"
                : "bg-ink-navy/5 text-ink-navy"
            }`}
            aria-live="polite"
          >
            <Clock className="w-4 h-4" />
            {isMock ? formatCountdown(timerSeconds) : formatCountUp(timerSeconds)}
          </span>

          <button
            onClick={onOpenPalette}
            className="lg:hidden p-2 rounded-lg bg-ink-navy/5 text-ink-navy"
            aria-label="Open question palette"
          >
            <Grid3x3 className="w-4 h-4" />
          </button>

          <button
            onClick={onSubmit}
            className="hidden sm:inline-flex bg-crimson text-white text-sm font-semibold px-4 py-2 rounded-lg hover:bg-crimson/90 transition-colors"
          >
            {isMock ? "Submit test" : "Submit practice"}
          </button>
        </div>
      </div>
    </header>
  );
}
