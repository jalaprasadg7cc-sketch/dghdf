import { Check, X } from "lucide-react";
import { QuestionOption } from "@/types";

interface OptionButtonProps {
  option: QuestionOption;
  isSelected: boolean;
  onSelect: () => void;
  disabled?: boolean;
  // Practice-mode-only feedback props
  showFeedback?: boolean;
  isCorrectOption?: boolean;
}

export default function OptionButton({
  option,
  isSelected,
  onSelect,
  disabled = false,
  showFeedback = false,
  isCorrectOption = false,
}: OptionButtonProps) {
  let stateClasses =
    "border-ink-navy/15 bg-white hover:border-ink-navy/30 hover:bg-ink-navy/[0.02]";
  let icon: React.ReactNode = null;

  if (showFeedback) {
    if (isCorrectOption) {
      stateClasses = "border-emerald bg-emerald-light";
      icon = <Check className="w-4 h-4 text-emerald shrink-0" strokeWidth={3} />;
    } else if (isSelected && !isCorrectOption) {
      stateClasses = "border-crimson bg-crimson-light";
      icon = <X className="w-4 h-4 text-crimson shrink-0" strokeWidth={3} />;
    } else {
      stateClasses = "border-ink-navy/10 bg-white opacity-60";
    }
  } else if (isSelected) {
    stateClasses = "border-ink-navy bg-ink-navy/5 ring-1 ring-ink-navy";
  }

  return (
    <button
      type="button"
      onClick={onSelect}
      disabled={disabled}
      aria-pressed={isSelected}
      className={`w-full flex items-center gap-3 text-left px-4 py-3.5 rounded-xl border-2 transition-colors duration-150 disabled:cursor-default ${stateClasses}`}
    >
      <span
        className={`w-7 h-7 shrink-0 rounded-full border-2 flex items-center justify-center font-mono text-xs font-semibold ${
          isSelected && !showFeedback
            ? "border-ink-navy bg-ink-navy text-paper"
            : "border-ink-navy/25 text-slate"
        }`}
      >
        {option.id}
      </span>
      <span className="font-sans text-sm text-ink-navy flex-1">{option.text}</span>
      {icon}
    </button>
  );
}
