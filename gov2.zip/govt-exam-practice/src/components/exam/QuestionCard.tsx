import { CheckCircle2, XCircle, Bookmark } from "lucide-react";
import { FeedbackMode, Question, UserAnswer } from "@/types";
import OptionButton from "@/components/exam/OptionButton";

interface QuestionCardProps {
  question: Question;
  answer: UserAnswer;
  feedbackMode: FeedbackMode;
  onSelectOption: (optionId: string) => void;
  onToggleMark: () => void;
}

export default function QuestionCard({
  question,
  answer,
  feedbackMode,
  onSelectOption,
  onToggleMark,
}: QuestionCardProps) {
  // "after-submit" sessions never reveal correctness or the correct option
  // while the user is working through questions — only Results does that.
  const showFeedback = feedbackMode === "immediate" && answer.checked;
  const isCorrect = answer.selectedOptionId === question.correctOptionId;

  return (
    <div className="bg-white rounded-2xl border border-ink-navy/10 p-6 sm:p-8">
      {/* Meta tags */}
      <div className="flex items-center flex-wrap gap-2 mb-5">
        <span className="text-xs font-mono px-2.5 py-1 rounded-full bg-ink-navy/5 text-slate">
          {question.topic}
        </span>
        <span className="text-xs font-mono px-2.5 py-1 rounded-full bg-ink-navy/5 text-slate">
          {question.year}
        </span>
        <span
          className={`text-xs font-mono px-2.5 py-1 rounded-full ${
            question.difficulty === "Easy"
              ? "bg-emerald-light text-emerald"
              : question.difficulty === "Medium"
              ? "bg-marigold/15 text-marigold-dark"
              : "bg-crimson-light text-crimson"
          }`}
        >
          {question.difficulty}
        </span>

        <button
          type="button"
          onClick={onToggleMark}
          aria-pressed={answer.markedForReview}
          className={`ml-auto inline-flex items-center gap-1.5 text-xs font-sans font-semibold px-3 py-1.5 rounded-full border transition-colors ${
            answer.markedForReview
              ? "bg-violet text-white border-violet"
              : "bg-white text-violet border-violet/40 hover:bg-violet-light"
          }`}
        >
          <Bookmark className="w-3.5 h-3.5" fill={answer.markedForReview ? "currentColor" : "none"} />
          {answer.markedForReview ? "Marked for review" : "Mark for review"}
        </button>
      </div>

      {/* Question text */}
      <p className="font-sans text-lg sm:text-xl text-ink-navy leading-relaxed mb-6">
        {question.questionText}
      </p>

      {/* Options */}
      <div className="flex flex-col gap-3">
        {question.options.map((option) => (
          <OptionButton
            key={option.id}
            option={option}
            isSelected={answer.selectedOptionId === option.id}
            onSelect={() => onSelectOption(option.id)}
            disabled={showFeedback}
            showFeedback={showFeedback}
            isCorrectOption={option.id === question.correctOptionId}
          />
        ))}
      </div>

      {/* Practice-mode feedback panel */}
      {showFeedback && (
        <div
          className={`mt-6 rounded-xl p-5 border ${
            isCorrect
              ? "bg-emerald-light border-emerald/30"
              : "bg-crimson-light border-crimson/30"
          }`}
        >
          <div className="flex items-center gap-2 mb-2">
            {isCorrect ? (
              <>
                <CheckCircle2 className="w-5 h-5 text-emerald" />
                <span className="font-sans font-semibold text-emerald text-sm">
                  Correct!
                </span>
              </>
            ) : (
              <>
                <XCircle className="w-5 h-5 text-crimson" />
                <span className="font-sans font-semibold text-crimson text-sm">
                  {answer.selectedOptionId ? "Not quite right" : "You didn't answer this one"}
                </span>
              </>
            )}
          </div>
          <p className="text-sm text-ink-navy/80 leading-relaxed">{question.explanation}</p>
        </div>
      )}
    </div>
  );
}
