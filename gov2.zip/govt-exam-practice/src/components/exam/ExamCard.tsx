import { Link } from "react-router-dom";
import { ArrowUpRight, FileText, Users } from "lucide-react";
import { Exam } from "@/types";

const accentMap: Record<Exam["colorAccent"], { bg: string; text: string; ring: string }> = {
  marigold: { bg: "bg-marigold/15", text: "text-marigold-dark", ring: "group-hover:ring-marigold" },
  emerald: { bg: "bg-emerald/10", text: "text-emerald", ring: "group-hover:ring-emerald" },
  navy: { bg: "bg-ink-navy/10", text: "text-ink-navy", ring: "group-hover:ring-ink-navy" },
  crimson: { bg: "bg-crimson/10", text: "text-crimson", ring: "group-hover:ring-crimson" },
};

function formatCount(n: number): string {
  if (n >= 1000) return `${(n / 1000).toFixed(n % 1000 === 0 ? 0 : 1)}k`;
  return `${n}`;
}

export default function ExamCard({ exam }: { exam: Exam }) {
  const accent = accentMap[exam.colorAccent];

  return (
    <Link
      to={`/exams/${exam.id}`}
      className={`group relative flex flex-col bg-white rounded-2xl p-6 border border-ink-navy/10 ring-1 ring-transparent transition-all hover:-translate-y-1 hover:shadow-lg ${accent.ring}`}
    >
      <div className="flex items-start justify-between mb-5">
        <span
          className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold font-sans ${accent.bg} ${accent.text}`}
        >
          {exam.category}
        </span>
        <ArrowUpRight className="w-5 h-5 text-slate group-hover:text-ink-navy group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
      </div>

      <h3 className="font-display text-2xl font-semibold text-ink-navy mb-1">
        {exam.name}
      </h3>
      <p className="text-sm text-slate mb-4 line-clamp-2">{exam.description}</p>

      <div className="mt-auto pt-4 border-t border-dashed border-ink-navy/15 flex items-center justify-between font-mono text-xs text-slate">
        <span className="flex items-center gap-1.5">
          <FileText className="w-3.5 h-3.5" />
          {exam.papersCount} papers
        </span>
        <span className="flex items-center gap-1.5">
          <Users className="w-3.5 h-3.5" />
          {formatCount(exam.aspirantsCount)} practicing
        </span>
      </div>
    </Link>
  );
}
