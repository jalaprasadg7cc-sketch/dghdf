import Modal from "@/components/common/Modal";
import Button from "@/components/common/Button";
import { ExamMode, SessionSummary } from "@/types";

interface SubmitModalProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  summary: SessionSummary;
  mode: ExamMode;
}

export default function SubmitModal({ open, onClose, onConfirm, summary, mode }: SubmitModalProps) {
  const rows = [
    { label: "Answered", value: summary.answered, color: "text-emerald" },
    { label: "Not answered", value: summary.notAnswered, color: "text-crimson" },
    { label: "Marked for review", value: summary.markedForReview, color: "text-violet" },
    { label: "Not visited", value: summary.notVisited, color: "text-ink-navy/60" },
  ];

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={mode === "mock-test" ? "Submit test?" : "End practice session?"}
      footer={
        <>
          <Button variant="ghost" size="sm" onClick={onClose}>
            Keep going
          </Button>
          <Button variant="secondary" size="sm" onClick={onConfirm}>
            {mode === "mock-test" ? "Submit test" : "Submit practice"}
          </Button>
        </>
      }
    >
      <p className="text-sm text-slate mb-5">
        {mode === "mock-test"
          ? "Once submitted, you won't be able to change any answers. Here's your current status:"
          : "Here's a summary of this practice session before you finish:"}
      </p>
      <div className="grid grid-cols-2 gap-4 font-mono">
        {rows.map((row) => (
          <div key={row.label} className="bg-paper rounded-xl px-4 py-3">
            <p className="text-xs text-slate mb-1">{row.label}</p>
            <p className={`text-2xl font-semibold ${row.color}`}>{row.value}</p>
          </div>
        ))}
      </div>
      {summary.notAnswered + summary.notVisited > 0 && (
        <p className="text-xs text-marigold-dark bg-marigold/10 rounded-lg px-3 py-2 mt-4">
          You have {summary.notAnswered + summary.notVisited} question
          {summary.notAnswered + summary.notVisited === 1 ? "" : "s"} without an answer.
        </p>
      )}
    </Modal>
  );
}
