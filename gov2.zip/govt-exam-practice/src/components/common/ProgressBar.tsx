interface ProgressBarProps {
  percent: number;
  label?: string;
  colorClass?: string;
}

export default function ProgressBar({ percent, label, colorClass = "bg-emerald" }: ProgressBarProps) {
  const clamped = Math.min(100, Math.max(0, percent));
  return (
    <div>
      {label && (
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-xs font-sans font-medium text-slate">{label}</span>
          <span className="text-xs font-mono text-slate">{clamped}%</span>
        </div>
      )}
      <div
        className="w-full h-1.5 rounded-full bg-ink-navy/10 overflow-hidden"
        role="progressbar"
        aria-valuenow={clamped}
        aria-valuemin={0}
        aria-valuemax={100}
      >
        <div
          className={`h-full rounded-full transition-all duration-300 ${colorClass}`}
          style={{ width: `${clamped}%` }}
        />
      </div>
    </div>
  );
}
