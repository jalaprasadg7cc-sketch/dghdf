// Central place for brand identity. Change these two lines to rebrand the whole app.
export const SITE_NAME = "PYQ Setu";
export const SITE_TAGLINE = "Practice. Not just PDFs.";

export const SITE_DESCRIPTION =
  "Interactive previous year question practice, mock tests and performance tracking for SSC, Banking, Railway, UPSC and State government exams.";
