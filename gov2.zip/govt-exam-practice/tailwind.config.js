/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        "ink-navy": "#12203D",
        "navy-light": "#1C3159",
        paper: "#F7F6F2",
        "paper-dark": "#EDEAE1",
        marigold: {
          DEFAULT: "#E8A33D",
          dark: "#C77F1F",
          light: "#F6D9A8",
        },
        emerald: {
          DEFAULT: "#1F7A5C",
          light: "#E4F3ED",
        },
        crimson: {
          DEFAULT: "#C1443C",
          light: "#F8E7E5",
        },
        violet: {
          DEFAULT: "#6C4FA3",
          light: "#EEE9F6",
        },
        slate: {
          DEFAULT: "#5B6472",
        },
      },
      fontFamily: {
        display: ["Fraunces", "serif"],
        sans: ["Inter", "sans-serif"],
        mono: ["IBM Plex Mono", "monospace"],
      },
      backgroundImage: {
        "perforation": "repeating-linear-gradient(to bottom, transparent 0 6px, #12203D22 6px 12px)",
      },
    },
  },
  plugins: [],
};
